import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';
import BirchLeaves from './components/BirchLeaves';
import HomePage from './pages/HomePage';
import MonumentsPage from './pages/MonumentsPage';
import MonumentDetailPage from './pages/MonumentDetailPage';
import MapPage from './pages/MapPage';
import HistoryPage from './pages/HistoryPage';
import RoutesPage from './pages/RoutesPage';
import PreservePage from './pages/PreservePage';
import './index.css';

export default function App() {
  return (
    <BrowserRouter>
      <div className="site-background" aria-hidden="true" />
      <BirchLeaves count={24} />
      <Navbar />
      <main style={{ minHeight: '100vh' }}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/monuments" element={<MonumentsPage />} />
          <Route path="/monument/:id" element={<MonumentDetailPage />} />
          <Route path="/map" element={<MapPage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/routes" element={<RoutesPage />} />
          <Route path="/preserve" element={<PreservePage />} />
          <Route path="*" element={
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', flexDirection: 'column', gap: '1rem', paddingTop: '70px' }}>
              <div style={{ fontSize: '5rem' }}>🗺️</div>
              <h1>Страница не найдена</h1>
              <a href="/" style={{ color: 'var(--color-green)', fontWeight: '600' }}>← На главную</a>
            </div>
          } />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
    </BrowserRouter>
  );
}
