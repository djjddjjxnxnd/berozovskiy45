import { useState } from 'react';
import { Link } from 'react-router-dom';
import FadeIn from '../components/FadeIn';
import {
  CameraIcon,
  ScrollIcon,
  ShieldIcon,
  BookIcon,
  HammersIcon,
  CompassIcon,
  NatureIcon,
  StarIcon,
  MapPinIcon,
} from '../components/Icons';

const steps = [
  {
    icon: CameraIcon,
    title: 'Документируйте',
    desc: 'Фотографируйте исторические здания, плотины и памятники. Снимки сохраняют образ города для будущих исследователей.',
  },
  {
    icon: ScrollIcon,
    title: 'Делитесь знаниями',
    desc: 'Рассказывайте друзьям и сверстникам об истории города. Используйте форму на сайте, чтобы сообщить о забытых объектах.',
  },
  {
    icon: ShieldIcon,
    title: 'Берегите старину',
    desc: 'Не наносите граффити, не ломайте кладку и памятные знаки, соблюдайте чистоту на территории объектов.',
  },
  {
    icon: BookIcon,
    title: 'Изучайте историю',
    desc: 'Посещайте Музей золота, читайте краеведческие исследования, записывайте воспоминания старожилов Берёзовского.',
  },
  {
    icon: HammersIcon,
    title: 'Поддерживайте проекты',
    desc: 'Участвуйте в школьных краеведческих конференциях, субботниках и волонтёрских инициативах города.',
  },
  {
    icon: CompassIcon,
    title: 'Привлекайте внимание',
    desc: 'Если старинному зданию или памятнику грозит разрушение — привлекайте внимание краеведов и общественности.',
  },
];

const whyMatters = [
  {
    icon: ScrollIcon,
    title: 'Живая связь поколений',
    text: 'Исторические объекты связывают нас с предками — первооткрывателями и горняками, которые создавали отечественную промышленность.',
  },
  {
    icon: NatureIcon,
    title: 'Уникальность города',
    text: 'Памятники и историческая среда формируют неповторимый облик Берёзовского, отличая его от других уральских поселений.',
  },
  {
    icon: BookIcon,
    title: 'Наглядное образование',
    text: 'Школьные уроки краеведения и экскурсии к подлинным памятникам воспитывают интерес к истории России лучше любых учебников.',
  },
  {
    icon: StarIcon,
    title: 'Память и гордость',
    text: 'Берёзовский — колыбель золота России. Сохранение этого статуса укрепляет чувство патриотизма и гордости за свой край.',
  },
];

function Toast({ message }) {
  return (
    <div className="toast">
      {message}
    </div>
  );
}

export default function PreservePage() {
  const [form, setForm] = useState({
    placeName: '',
    location: '',
    shortDesc: '',
    history: '',
    photo: null,
    photoName: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [toast, setToast] = useState(null);
  const [savedPlaces, setSavedPlaces] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('berezovsky_saved_places') || '[]');
    } catch {
      return [];
    }
  });

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
  };

  const handleFile = e => {
    const file = e.target.files[0];
    if (file) {
      setForm(f => ({ ...f, photo: file, photoName: file.name }));
    }
  };

  const handleSubmit = e => {
    e.preventDefault();
    if (!form.placeName || !form.location || !form.shortDesc) {
      setToast('Заполните обязательные поля');
      setTimeout(() => setToast(null), 3000);
      return;
    }

    const entry = {
      id: Date.now(),
      ...form,
      photo: form.photoName || null,
      savedAt: new Date().toLocaleString('ru-RU'),
    };

    const updated = [...savedPlaces, entry];
    setSavedPlaces(updated);
    try {
      localStorage.setItem('berezovsky_saved_places', JSON.stringify(updated));
    } catch {}

    setSubmitted(true);
    setForm({ placeName: '', location: '', shortDesc: '', history: '', photo: null, photoName: '' });
    setToast('Данные об объекте сохранены в браузере!');
    setTimeout(() => setToast(null), 3500);
  };

  return (
    <>
      {toast && <Toast message={toast} />}

      {/* Шапка */}
      <div style={{
        background: 'linear-gradient(135deg, var(--color-dark-green), #0d3320)',
        paddingTop: '70px',
        padding: '120px 2rem 3rem',
        color: 'white',
      }}>
        <div className="container">
          <div className="breadcrumb">
            <Link to="/">Главная</Link>
            <span className="breadcrumb-sep">›</span>
            <span>Сохраним историю вместе</span>
          </div>
          <h1>Сохраним историю вместе</h1>
          <p style={{ color: 'rgba(255,255,255,0.75)', marginTop: '0.75rem', fontSize: '1.05rem' }}>
            Общественная и исследовательская миссия проекта по защите культурного наследия Берёзовского
          </p>
        </div>
      </div>

      {/* Почему важно */}
      <section className="section section-white">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">О проблеме</span>
              <h2>Почему исторические памятники нуждаются в защите?</h2>
              <p>
                Берёзовский хранит славу первого золотого города России. Без нашего внимания многие памятники могут исчезнуть навсегда.
              </p>
            </div>
          </FadeIn>

          <div className="grid-2" style={{ marginBottom: '3rem' }}>
            {whyMatters.map((item, i) => {
              const ItemIcon = item.icon;
              return (
                <FadeIn key={i} delay={i * 100}>
                  <div style={{
                    display: 'flex',
                    gap: '1.5rem',
                    padding: '1.75rem',
                    background: 'var(--color-beige)',
                    borderRadius: '14px',
                    alignItems: 'flex-start',
                    boxShadow: '0 2px 10px rgba(0,0,0,0.03)',
                  }}>
                    <div style={{
                      width: '54px',
                      height: '54px',
                      background: 'var(--color-gold)',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'var(--color-dark-green)',
                      flexShrink: 0,
                    }}>
                      <ItemIcon width={28} height={28} />
                    </div>
                    <div>
                      <h3 style={{ marginBottom: '0.5rem', color: 'var(--color-dark-green)', fontSize: '1.1rem' }}>
                        {item.title}
                      </h3>
                      <p style={{ color: 'var(--color-text-light)', fontSize: '0.92rem', margin: 0, lineHeight: '1.6' }}>{item.text}</p>
                    </div>
                  </div>
                </FadeIn>
              );
            })}
          </div>

          <FadeIn>
            <div style={{
              background: 'linear-gradient(135deg, #1a4731, #0d3320)',
              borderRadius: '16px',
              padding: '2.5rem',
              color: 'white',
              boxShadow: '0 5px 25px rgba(0,0,0,0.1)',
            }}>
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                background: 'rgba(201,162,39,0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--color-gold-light)',
                marginBottom: '1rem',
              }}>
                <ShieldIcon width={26} height={26} />
              </div>
              <h3 style={{ color: 'var(--color-gold-light)', marginBottom: '1rem' }}>
                Актуальная краеведческая проблема
              </h3>
              <p style={{ color: 'rgba(255,255,255,0.9)', lineHeight: '1.8', marginBottom: '1rem', fontSize: '0.98rem' }}>
                Многие жители Берёзовского, особенно молодёжь и школьники, мало знают об исторических местах своего города.
                Памятники, старинные здания и гидротехнические сооружения XVIII–XIX веков ветшают без должного ухода и охранного статуса.
              </p>
              <p style={{ color: 'rgba(255,255,255,0.75)', lineHeight: '1.8', margin: 0, fontSize: '0.95rem' }}>
                Проект «Неизвестный Берёзовский» привлекает внимание к историческому богатству родного края:
                чтобы сберечь наследие, его необходимо знать, ценить и популяризировать.
              </p>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* Как помочь */}
      <section className="section section-beige">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Действия</span>
              <h2>Что может сделать каждый из нас</h2>
              <p>Сохранение культурного наследия — общее дело всех жителей города</p>
            </div>
          </FadeIn>

          <div className="grid-3">
            {steps.map((step, i) => {
              const StepIcon = step.icon;
              return (
                <FadeIn key={i} delay={i * 80}>
                  <div className="save-step" style={{
                    background: 'white',
                    borderRadius: '14px',
                    padding: '1.75rem',
                    flexDirection: 'column',
                    gap: '1rem',
                    boxShadow: '0 2px 15px rgba(0,0,0,0.04)',
                  }}>
                    <div style={{
                      width: '52px',
                      height: '52px',
                      background: 'rgba(45,106,79,0.1)',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'var(--color-green)',
                      flexShrink: 0,
                    }}>
                      <StepIcon width={26} height={26} />
                    </div>
                    <div>
                      <h3 style={{ color: 'var(--color-dark-green)', marginBottom: '0.5rem', fontSize: '1.05rem' }}>
                        {step.title}
                      </h3>
                      <p style={{ color: 'var(--color-text-light)', fontSize: '0.92rem', margin: 0, lineHeight: '1.6' }}>{step.desc}</p>
                    </div>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* Интерактивная форма */}
      <section id="form" className="section section-white">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Краеведческая анкета</span>
              <h2>Расскажи о забытом месте</h2>
              <p>
                Знаете старинный дом, шурф, памятный знак или место, не отмеченное на карте?
                Напишите о нём — и внесите свой вклад в проект!
              </p>
            </div>
          </FadeIn>

          <div style={{ maxWidth: '720px', margin: '0 auto' }}>
            <FadeIn>
              <div className="alert alert-warning" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
                <ShieldIcon width={20} height={20} color="#856404" />
                <span>
                  <strong>Демонстрационный режим:</strong> Это школьный исследовательский проект.
                  Введённые данные сохраняются локально в вашем браузере (localStorage) и не отправляются во внешние базы данных.
                </span>
              </div>
            </FadeIn>

            {submitted && (
              <FadeIn>
                <div style={{
                  background: 'rgba(45,106,79,0.08)',
                  border: '2px solid var(--color-green)',
                  borderRadius: '14px',
                  padding: '2.5rem 2rem',
                  textAlign: 'center',
                  marginBottom: '2rem',
                }}>
                  <div style={{
                    width: '64px',
                    height: '64px',
                    borderRadius: '50%',
                    background: 'var(--color-green)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 1rem',
                    color: 'white',
                  }}>
                    <ScrollIcon width={32} height={32} />
                  </div>
                  <h3 style={{ color: 'var(--color-dark-green)', marginBottom: '0.5rem' }}>
                    Спасибо за вклад в краеведение!
                  </h3>
                  <p style={{ color: 'var(--color-text-light)', maxWidth: '480px', margin: '0 auto 1.5rem' }}>
                    Запись успешно сохранена в вашем браузере. Вы можете добавить другие известные вам исторические объекты.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="btn btn-green btn-sm"
                  >
                    Добавить ещё объект
                  </button>
                </div>
              </FadeIn>
            )}

            {!submitted && (
              <FadeIn delay={100}>
                <form
                  onSubmit={handleSubmit}
                  style={{
                    background: 'white',
                    borderRadius: '16px',
                    padding: '2.5rem',
                    boxShadow: '0 5px 30px rgba(0,0,0,0.08)',
                    border: '1px solid #eee',
                  }}
                >
                  <div className="form-group">
                    <label className="form-label">
                      Название объекта или места <span style={{ color: '#c9a227' }}>*</span>
                    </label>
                    <input
                      type="text"
                      name="placeName"
                      className="form-control"
                      placeholder="Например: Старинная шахтная крепь в лесу у речки"
                      value={form.placeName}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">
                      Местоположение / ориентиры <span style={{ color: '#c9a227' }}>*</span>
                    </label>
                    <input
                      type="text"
                      name="location"
                      className="form-control"
                      placeholder="Адрес, район или географические ориентиры"
                      value={form.location}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">
                      Краткое описание <span style={{ color: '#c9a227' }}>*</span>
                    </label>
                    <textarea
                      name="shortDesc"
                      className="form-control"
                      placeholder="Что представляет собой этот объект? В каком он состоянии?"
                      value={form.shortDesc}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">
                      Исторические сведения и предания (если известны)
                    </label>
                    <textarea
                      name="history"
                      className="form-control"
                      placeholder="Что рассказывают старожилы? Из каких источников вам известно об этом месте?"
                      value={form.history}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">
                      Прикрепить фотографию
                    </label>
                    <div style={{
                      border: '2px dashed #ccc',
                      borderRadius: '10px',
                      padding: '1.75rem',
                      textAlign: 'center',
                      cursor: 'pointer',
                      background: form.photoName ? 'rgba(45,106,79,0.05)' : '#fafafa',
                      transition: 'all 0.2s',
                    }}
                      onClick={() => document.getElementById('photo-upload').click()}
                    >
                      <input
                        id="photo-upload"
                        type="file"
                        accept="image/*"
                        style={{ display: 'none' }}
                        onChange={handleFile}
                      />
                      {form.photoName ? (
                        <div>
                          <div style={{ color: 'var(--color-green)', marginBottom: '0.4rem', display: 'flex', justifyContent: 'center' }}>
                            <CameraIcon width={32} height={32} />
                          </div>
                          <p style={{ color: 'var(--color-green)', fontWeight: '600', margin: 0, fontSize: '0.95rem' }}>
                            {form.photoName}
                          </p>
                        </div>
                      ) : (
                        <div>
                          <div style={{ color: 'var(--color-text-light)', marginBottom: '0.4rem', display: 'flex', justifyContent: 'center' }}>
                            <CameraIcon width={32} height={32} />
                          </div>
                          <p style={{ color: 'var(--color-text-light)', margin: 0, fontSize: '0.92rem' }}>
                            Нажмите, чтобы прикрепить файл фотографии
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <button type="submit" className="btn btn-green" style={{ width: '100%', justifyContent: 'center', marginTop: '1rem' }}>
                    <ScrollIcon width={18} height={18} color="white" />
                    <span>Сохранить объект в проекте</span>
                  </button>
                </form>
              </FadeIn>
            )}

            {/* Сохранённые объекты */}
            {savedPlaces.length > 0 && (
              <FadeIn>
                <div style={{ marginTop: '3rem' }}>
                  <h3 style={{ marginBottom: '1.25rem', color: 'var(--color-dark-green)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <ScrollIcon width={20} height={20} color="var(--color-green)" />
                    <span>Добавленные вами объекты (сохранены в браузере):</span>
                  </h3>
                  {savedPlaces.map(place => (
                    <div key={place.id} style={{
                      background: 'white',
                      borderRadius: '12px',
                      padding: '1.25rem 1.5rem',
                      marginBottom: '1rem',
                      boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
                      border: '1px solid #eee',
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem' }}>
                        <div>
                          <h4 style={{ color: 'var(--color-dark-green)', marginBottom: '0.35rem' }}>{place.placeName}</h4>
                          <p style={{ fontSize: '0.85rem', color: 'var(--color-text-light)', margin: 0 }}>
                            📍 {place.location} &nbsp;·&nbsp; Дата: {place.savedAt}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            const updated = savedPlaces.filter(p => p.id !== place.id);
                            setSavedPlaces(updated);
                            try { localStorage.setItem('berezovsky_saved_places', JSON.stringify(updated)); } catch {}
                          }}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: '#999',
                            cursor: 'pointer',
                            fontSize: '1.1rem',
                            padding: '4px',
                          }}
                          title="Удалить"
                        >✕</button>
                      </div>
                    </div>
                  ))}
                </div>
              </FadeIn>
            )}
          </div>
        </div>
      </section>

      {/* Источники */}
      <section id="sources" className="section section-beige">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Историография</span>
              <h2>Научные и краеведческие источники</h2>
              <p>Все исторические данные и датировки проверены по открытым источникам</p>
            </div>
          </FadeIn>

          <div className="grid-2">
            {[
              {
                title: 'Музей истории золотодобывающей промышленности Урала',
                detail: 'г. Берёзовский, ул. Николая Чусовитина, 2. Экспозиция и архивные материалы.',
                link: null,
              },
              {
                title: 'Администрация Берёзовского городского округа',
                detail: 'Официальный информационный портал города Берёзовский.',
                link: 'https://berezovsky.ru',
              },
              {
                title: 'Управление государственной охраны объектов культурного наследия',
                detail: 'Официальный реестр памятников истории и архитектуры Свердловской области.',
                link: null,
              },
              {
                title: 'OpenStreetMap contributors',
                detail: 'Картографическая основа геоданных с открытой лицензией ODbL.',
                link: 'https://openstreetmap.org',
              },
              {
                title: 'Открытые краеведческие архивы Урала',
                detail: 'Исторические фотографии С. М. Прокудина-Горского (1910 г.) и краеведческие летописи.',
                link: null,
              },
              {
                title: 'Уральское геологическое общество и музей',
                detail: 'Материалы по истории открытий месторождений золота и редких минералов Берёзовского.',
                link: null,
              },
            ].map((src, i) => (
              <FadeIn key={i} delay={i * 80}>
                <div style={{
                  background: 'white',
                  borderRadius: '12px',
                  padding: '1.5rem',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.04)',
                }}>
                  <h4 style={{ color: 'var(--color-dark-green)', marginBottom: '0.5rem', fontSize: '1rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <BookIcon width={16} height={16} color="var(--color-green)" />
                    <span>{src.title}</span>
                  </h4>
                  <p style={{ color: 'var(--color-text-light)', fontSize: '0.88rem', margin: 0, lineHeight: '1.5' }}>
                    {src.detail}
                  </p>
                  {src.link && (
                    <a href={src.link} target="_blank" rel="noreferrer" style={{
                      color: 'var(--color-green)',
                      fontSize: '0.85rem',
                      fontWeight: '600',
                      display: 'inline-block',
                      marginTop: '0.5rem',
                    }}>
                      Перейти на сайт →
                    </a>
                  )}
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
