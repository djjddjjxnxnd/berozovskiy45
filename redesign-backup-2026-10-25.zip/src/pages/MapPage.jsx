import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import YandexMap from '../components/YandexMap';
import { monuments, categories } from '../data/monuments';
import FadeIn from '../components/FadeIn';
import { useUserLocation, calculateDistance, formatDistance } from '../utils/useUserLocation';
import {
  HammersIcon,
  MonumentIcon,
  ChurchIcon,
  MuseumIcon,
  StarIcon,
  HiddenPlaceIcon,
  MapPinIcon,
  CompassIcon,
  ScrollIcon,
  ParkIcon,
} from '../components/Icons';

const iconMap = {
  all: HammersIcon,
  monument: MonumentIcon,
  museum: MuseumIcon,
  architecture: ChurchIcon,
  memorial: StarIcon,
  leisure: ParkIcon,
  hidden: HiddenPlaceIcon,
};

const categoryColors = {
  monument: '#c9a227',
  museum: '#1a4731',
  architecture: '#2d6a4f',
  memorial: '#dc3545',
  leisure: '#198754',
  hidden: '#856404',
};

export default function MapPage() {
  const [searchParams] = useSearchParams();
  const focusId = searchParams.get('id');
  const [activeCategory, setActiveCategory] = useState('all');
  const [selected, setSelected] = useState(null);
  const [filtered, setFiltered] = useState(monuments);

  const { location: userLocation, loading: geoLoading, error: geoError, requestLocation } = useUserLocation();

  const focusMonument = focusId ? monuments.find(m => m.id === parseInt(focusId)) : null;

  useEffect(() => {
    if (activeCategory === 'all') {
      setFiltered(monuments);
    } else {
      setFiltered(monuments.filter(m => m.category === activeCategory));
    }
  }, [activeCategory]);

  useEffect(() => {
    if (focusMonument) setSelected(focusMonument);
  }, [focusId]);

  // Расчёт расстояния от пользователя до выбранного памятника
  let userDistanceInfo = null;
  if (userLocation && selected) {
    const dist = calculateDistance(userLocation.lat, userLocation.lng, selected.lat, selected.lng);
    userDistanceInfo = formatDistance(dist);
  }

  // Ссылки на построение маршрута
  const yandexRouteUrl = selected
    ? userLocation
      ? `https://yandex.ru/maps/?rtext=${userLocation.lat}%2C${userLocation.lng}~${selected.lat}%2C${selected.lng}&rtt=pd`
      : `https://yandex.ru/maps/?rtext=~${selected.lat}%2C${selected.lng}&rtt=pd`
    : '#';

  const googleRouteUrl = selected
    ? userLocation
      ? `https://www.google.com/maps/dir/${userLocation.lat},${userLocation.lng}/${selected.lat},${selected.lng}`
      : `https://www.google.com/maps/dir/?api=1&destination=${selected.lat},${selected.lng}`
    : '#';

  return (
    <>
      {/* Шапка */}
      <div style={{
        background: 'linear-gradient(135deg, var(--color-dark-green), #0d3320)',
        paddingTop: '70px',
        padding: '120px 2rem 3rem',
        color: 'white',
      }}>
        <div className="container">
          <div className="breadcrumb">
            <Link to="/">Главная</Link>
            <span className="breadcrumb-sep">›</span>
            <span>Карта</span>
          </div>
          <h1>Интерактивная карта Берёзовского</h1>
          <p style={{ color: 'rgba(255,255,255,0.75)', marginTop: '0.75rem', fontSize: '1.05rem' }}>
            Памятники, музеи, храмы и зоны отдыха с точной навигацией и определением вашей геопозиции
          </p>
        </div>
      </div>

      <section className="section section-beige" style={{ paddingTop: '2rem' }}>
        <div className="container">

          {/* Плашка геолокации и фильтры */}
          <FadeIn>
            <div style={{
              background: 'white',
              borderRadius: '14px',
              padding: '1rem 1.5rem',
              marginBottom: '1.5rem',
              boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '1rem',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{
                  width: '38px',
                  height: '38px',
                  borderRadius: '50%',
                  background: userLocation ? 'rgba(45,106,79,0.1)' : 'rgba(252,63,29,0.1)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: userLocation ? 'var(--color-green)' : '#fc3f1d',
                  flexShrink: 0,
                }}>
                  <MapPinIcon width={20} height={20} />
                </div>
                <div>
                  <div style={{ fontWeight: '700', fontSize: '0.92rem', color: 'var(--color-dark-green)' }}>
                    {userLocation ? 'Ваша геопозиция определена' : 'Построить точный маршрут от вас'}
                  </div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--color-text-light)' }}>
                    {userLocation
                      ? `Координаты: ${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)} · Маршруты строятся от вашей текущей точки`
                      : 'Нажмите кнопку, чтобы сайт запросил геопозицию и проложил маршрут прямо от вас'}
                  </div>
                  {geoError && (
                    <div style={{ fontSize: '0.78rem', color: '#dc3545', marginTop: '2px' }}>
                      {geoError}
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={requestLocation}
                disabled={geoLoading}
                style={{
                  background: userLocation ? '#2d6a4f' : '#fc3f1d',
                  color: 'white',
                  borderRadius: '50px',
                  padding: '0.55rem 1.3rem',
                  fontWeight: '700',
                  fontSize: '0.85rem',
                  border: 'none',
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                }}
              >
                <span>{geoLoading ? 'Определение...' : userLocation ? 'Обновить где я' : 'Определить где я'}</span>
              </button>
            </div>
          </FadeIn>

          {/* Фильтры категорий */}
          <FadeIn>
            <div className="filter-tabs" style={{ marginBottom: '1.5rem' }}>
              {categories.map(cat => {
                const IconComp = iconMap[cat.id] || HammersIcon;
                const isActive = activeCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    className={`filter-tab${isActive ? ' active' : ''}`}
                    onClick={() => setActiveCategory(cat.id)}
                    style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}
                  >
                    <IconComp width={16} height={16} color={isActive ? 'white' : 'var(--color-green)'} />
                    <span>{cat.label}</span>
                  </button>
                );
              })}
            </div>
          </FadeIn>

          <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 390px' : '1fr', gap: '1.5rem', alignItems: 'start' }}>
            {/* Яндекс Карта */}
            <FadeIn>
              <YandexMap
                monuments={filtered}
                selectedMonument={selected}
                onSelectMonument={setSelected}
                center={[56.9150, 60.8120]}
                zoom={13}
                height="580px"
                userLocation={userLocation}
              />
            </FadeIn>

            {/* Боковая карточка выбранного объекта */}
            {selected && (
              <FadeIn>
                <div style={{
                  background: 'white',
                  borderRadius: '14px',
                  overflow: 'hidden',
                  boxShadow: '0 5px 30px rgba(0,0,0,0.15)',
                  position: 'sticky',
                  top: '80px',
                  border: '1px solid #eaeaea',
                }}>
                  <div style={{ position: 'relative' }}>
                    <img
                      src={selected.image}
                      alt={selected.name}
                      style={{
                        width: '100%',
                        height: '210px',
                        objectFit: 'cover',
                        objectPosition: selected.id === 1 ? 'top 15% center' : 'center center',
                        display: 'block',
                      }}
                      onError={e => { e.target.style.display = 'none'; }}
                    />
                    <button
                      onClick={() => setSelected(null)}
                      style={{
                        position: 'absolute',
                        top: '10px',
                        right: '10px',
                        background: 'rgba(0,0,0,0.65)',
                        border: 'none',
                        color: 'white',
                        width: '32px',
                        height: '32px',
                        borderRadius: '50%',
                        cursor: 'pointer',
                        fontSize: '1rem',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                      title="Закрыть"
                    >✕</button>
                  </div>

                  <div style={{ padding: '1.5rem' }}>
                    <div style={{
                      display: 'inline-block',
                      background: 'rgba(45,106,79,0.1)',
                      color: 'var(--color-green)',
                      fontSize: '0.75rem',
                      padding: '0.25rem 0.75rem',
                      borderRadius: '50px',
                      marginBottom: '0.75rem',
                      fontWeight: '700',
                    }}>
                      {categories.find(c => c.id === selected.category)?.label}
                    </div>

                    <h3 style={{ color: 'var(--color-dark-green)', marginBottom: '0.5rem', fontSize: '1.15rem' }}>
                      {selected.name}
                    </h3>

                    <p style={{
                      fontSize: '0.82rem',
                      color: 'var(--color-gold)',
                      marginBottom: '0.75rem',
                      fontWeight: '600',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                    }}>
                      <MapPinIcon width={14} height={14} color="var(--color-gold)" />
                      <span>{selected.address}</span>
                    </p>

                    {/* Расстояние от текущей геопозиции пользователя */}
                    {userDistanceInfo && (
                      <div style={{
                        background: 'rgba(45,106,79,0.08)',
                        border: '1px solid rgba(45,106,79,0.2)',
                        borderRadius: '8px',
                        padding: '0.6rem 0.85rem',
                        marginBottom: '0.85rem',
                        fontSize: '0.84rem',
                        color: 'var(--color-dark-green)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}>
                        <span>🚶</span>
                        <span>Расстояние от вас: <strong>{userDistanceInfo.text}</strong> ({userDistanceInfo.walkTime})</span>
                      </div>
                    )}

                    <p style={{ color: 'var(--color-text-light)', fontSize: '0.9rem', marginBottom: '1.25rem', lineHeight: '1.55' }}>
                      {selected.shortDesc}
                    </p>

                    {selected.status && (
                      <p style={{ fontSize: '0.8rem', color: 'var(--color-green)', marginBottom: '1.25rem', fontWeight: '600' }}>
                        ● {selected.status}
                      </p>
                    )}

                    {/* Кнопки навигации */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                      <Link
                        to={`/monument/${selected.id}`}
                        className="btn btn-green btn-sm"
                        style={{ justifyContent: 'center' }}
                      >
                        <ScrollIcon width={16} height={16} color="white" />
                        <span>Узнать историю объекта</span>
                      </Link>

                      {/* Яндекс Карты с точкой пользователя */}
                      <a
                        href={yandexRouteUrl}
                        target="_blank"
                        rel="noreferrer"
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '6px',
                          padding: '0.6rem 1.2rem',
                          borderRadius: '50px',
                          color: '#fff',
                          background: '#fc3f1d',
                          fontWeight: '700',
                          fontSize: '0.88rem',
                          textDecoration: 'none',
                          boxShadow: '0 3px 10px rgba(252,63,29,0.3)',
                        }}
                      >
                        <span>{userLocation ? 'Маршрут от меня в Яндекс Картах' : 'Маршрут в Яндекс Картах'}</span>
                      </a>

                      {/* Google Maps */}
                      <a
                        href={googleRouteUrl}
                        target="_blank"
                        rel="noreferrer"
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '6px',
                          padding: '0.6rem 1.2rem',
                          borderRadius: '50px',
                          color: '#1a73e8',
                          background: '#e8f0fe',
                          border: '1px solid #d2e3fc',
                          fontWeight: '700',
                          fontSize: '0.88rem',
                          textDecoration: 'none',
                        }}
                      >
                        <span>В Google Maps</span>
                      </a>
                    </div>
                  </div>
                </div>
              </FadeIn>
            )}
          </div>

          {/* Список объектов под картой */}
          <FadeIn>
            <div style={{ marginTop: '3rem' }}>
              <h2 style={{ marginBottom: '1.5rem', color: 'var(--color-dark-green)' }}>
                Все объекты города Берёзовского
              </h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
                {filtered.map(m => {
                  const CatIcon = iconMap[m.category] || MonumentIcon;
                  return (
                    <div
                      key={m.id}
                      onClick={() => setSelected(m)}
                      style={{
                        background: 'white',
                        borderRadius: '12px',
                        padding: '1rem 1.25rem',
                        cursor: 'pointer',
                        border: selected?.id === m.id ? '2px solid #fc3f1d' : '2px solid transparent',
                        boxShadow: '0 2px 10px rgba(0,0,0,0.06)',
                        transition: 'all 0.2s',
                        display: 'flex',
                        gap: '1rem',
                        alignItems: 'center',
                      }}
                      onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 5px 20px rgba(0,0,0,0.12)'; }}
                      onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = '0 2px 10px rgba(0,0,0,0.06)'; }}
                    >
                      <div style={{
                        width: '42px',
                        height: '42px',
                        background: categoryColors[m.category] || '#c9a227',
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexShrink: 0,
                        color: 'white',
                      }}>
                        <CatIcon width={22} height={22} color="white" />
                      </div>
                      <div>
                        <div style={{ fontWeight: '700', fontSize: '0.92rem', color: 'var(--color-dark-green)', marginBottom: '0.2rem' }}>
                          {m.name}
                        </div>
                        <div style={{ fontSize: '0.78rem', color: 'var(--color-text-light)' }}>
                          {m.address}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
