import { Link } from 'react-router-dom';
import { monuments } from '../data/monuments';
import MonumentCard from '../components/MonumentCard';
import FadeIn from '../components/FadeIn';
import {
  PickaxeIcon,
  MicroscopeIcon,
  MedalIcon,
  NatureIcon,
  PersonIcon,
  MuseumIcon,
  GoldIcon,
  HammersIcon,
  FactoryIcon,
  CompassIcon,
  MapPinIcon,
  ScrollIcon,
  ShieldIcon,
  GoldNuggetMark,
  MineMark,
  ArchiveMark,
  CityMark,
} from '../components/Icons';

const facts = [
  { icon: GoldNuggetMark, number: '1745', label: 'год открытия золота Ерофеем Марковым' },
  { icon: MineMark, number: '275+', label: 'лет непрерывной золотодобычи' },
  { icon: ArchiveMark, number: '1816', label: 'год основания Музея золота' },
  { icon: CityMark, number: '60 000+', label: 'жителей современного Берёзовского' },
];

const highlights = [
  {
    icon: GoldIcon,
    title: 'Первое золото России',
    text: 'В 1745 году крестьянин Ерофей Марков нашёл близ Берёзовского первое в России рудное золото. Это открытие навсегда изменило судьбу и мощь страны.',
  },
  {
    icon: FactoryIcon,
    title: 'Горнозаводская колыбель',
    text: 'На протяжении более 150 лет Берёзовский оставался главным центром золотодобычи страны. Здесь построили первую промышленную золотопромывальную фабрику.',
  },
  {
    icon: MicroscopeIcon,
    title: 'Революция Льва Брусницына',
    text: 'В 1814 году берёзовский горный мастер разработал уникальный метод промывки золота из россыпей, изменивший всю мировую практику золотодобычи.',
  },
  {
    icon: MuseumIcon,
    title: 'Живая история',
    text: 'Сегодня в Берёзовском можно спуститься в настоящую учебную шахту, посетить старейший музей золота и прикоснуться к 275-летней горной летописи.',
  },
];

// Карточки «Знаете ли вы?», на которые указал пользователь
const didYouKnow = [
  {
    icon: PickaxeIcon,
    text: 'Берёзовское месторождение — одно из старейших непрерывно действующих золотых рудников мира. Добыча не прекращается с 1748 года — уже более 275 лет.',
  },
  {
    icon: MicroscopeIcon,
    text: 'Именно в Берёзовском горный мастер Лев Брусницын в 1814 году впервые разработал метод промышленной добычи золота из россыпей, изменивший всю мировую золотодобычу.',
  },
  {
    icon: MedalIcon,
    text: 'Музей истории золотодобычи в Берёзовском основан в 1816 году — это один из старейших горнозаводских музеев не только России, но и мира.',
  },
  {
    icon: NatureIcon,
    text: 'Берёзовский находится всего в 11 км к северо-востоку от Екатеринбурга, но большинство туристов обходят его стороной, не подозревая о богатой истории.',
  },
  {
    icon: PersonIcon,
    text: 'Ерофей Марков, открывший золото России, был простым крестьянином из деревни Шарташ. Его случайная находка изменила ход российской истории.',
  },
  {
    icon: MuseumIcon,
    text: 'В Берёзовском действует туристическая шахта, где посетители могут спуститься в настоящую горную выработку и ощутить атмосферу XIX века.',
  },
];

export default function HomePage() {
  const featured = monuments.slice(0, 4);

  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="hero-bg" />
        <div className="hero-overlay" />

        <div className="hero-content">
          <div style={{ marginBottom: '1.25rem' }}>
            <img
              src="/coat-of-arms.webp"
              alt="Официальный герб города Берёзовский"
              style={{
                width: '78px',
                height: 'auto',
                filter: 'drop-shadow(0 6px 16px rgba(0,0,0,0.45))',
                animation: 'fadeInUp 0.8s ease forwards',
              }}
            />
          </div>
          <div className="hero-badge">
            Урал · Свердловская область
          </div>
          <h1>
            <span className="highlight">Неизвестный</span><br />
            Берёзовский
          </h1>
          <p className="hero-subtitle">
            Открой историю родного города. Узнай о забытых памятниках, интересных местах
            и людях, оставивших след в истории первого золотого города России.
          </p>

          <div className="hero-buttons">
            <Link to="/monuments" className="btn btn-primary">
              <MuseumIcon width={20} height={20} color="var(--color-dark-green)" />
              <span>Исследовать памятники</span>
            </Link>
            <Link to="/map" className="btn btn-outline">
              <CompassIcon width={20} height={20} color="white" />
              <span>Открыть карту</span>
            </Link>
          </div>
        </div>

        <div className="hero-scroll" onClick={() => window.scrollTo({ top: window.innerHeight, behavior: 'smooth' })}>
          <span>Прокрути вниз</span>
          <div className="scroll-arrow" />
        </div>
      </section>

      {/* ФАКТЫ В ЦИФРАХ */}
      <section className="section section-dark">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Берёзовский в цифрах</span>
              <h2 style={{ color: 'white' }}>История, записанная в фактах</h2>
              <p>Берёзовский — небольшой город с великой историей</p>
            </div>
          </FadeIn>

          <div className="facts-grid">
            {facts.map((f, i) => {
              const IconComponent = f.icon;
              return (
                <FadeIn key={i} delay={i * 100}>
                  <div className="fact-card">
                    <div className="fact-icon-badge">
                      <IconComponent width={28} height={28} />
                    </div>
                    <div className="fact-number">{f.number}</div>
                    <div className="fact-label">{f.label}</div>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* ПОЧЕМУ ВАЖНО */}
      <section className="section section-beige">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">О проекте</span>
              <h2>Почему важно сохранять историю?</h2>
              <p>
                История города — это история людей. Каждый памятник, каждое историческое здание
                несёт в себе память о тех, кто жил и трудился на этой земле.
              </p>
            </div>
          </FadeIn>

          <div className="grid-2" style={{ alignItems: 'center', gap: '3rem' }}>
            <FadeIn delay={100}>
              <div>
                <p style={{ fontSize: '1.05rem', lineHeight: '1.8', marginBottom: '1.5rem', color: 'var(--color-text)' }}>
                  Берёзовский — это не просто город-спутник Екатеринбурга. Это место, где в 1745 году
                  было открыто первое в России рудное золото, где зародилась отечественная
                  золотодобывающая промышленность, где история страны менялась навсегда.
                </p>
                <p style={{ fontSize: '1.05rem', lineHeight: '1.8', marginBottom: '1.5rem', color: 'var(--color-text)' }}>
                  Многие жители города, особенно молодёжь, мало знают об этих местах.
                  Некоторые исторические объекты постепенно теряют свой облик или остаются
                  без должного внимания.
                </p>
                <p style={{ fontSize: '1.05rem', lineHeight: '1.8', color: 'var(--color-text)' }}>
                  Этот сайт создан в рамках школьного исследовательского проекта, чтобы показать:
                  в Берёзовском есть что исследовать и беречь. История родного края принадлежит всем нам.
                </p>
              </div>
            </FadeIn>

            <FadeIn delay={200}>
              <div style={{
                background: 'linear-gradient(135deg, var(--color-dark-green), #0d3320)',
                borderRadius: '16px',
                padding: '2.5rem',
                color: 'white',
                border: '1px solid rgba(201,162,39,0.3)',
                boxShadow: '0 10px 30px rgba(0,0,0,0.15)',
              }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  borderRadius: '50%',
                  background: 'rgba(201,162,39,0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem',
                  color: 'var(--color-gold-light)',
                }}>
                  <ScrollIcon width={32} height={32} />
                </div>
                <blockquote style={{
                  fontSize: '1.15rem',
                  fontStyle: 'italic',
                  lineHeight: '1.7',
                  textAlign: 'center',
                  color: 'rgba(255,255,255,0.95)',
                  margin: 0,
                }}>
                  «Чтобы сохранить историю родного города,
                  сначала нужно её узнать»
                </blockquote>
                <p style={{
                  textAlign: 'center',
                  color: 'var(--color-gold-light)',
                  marginTop: '1.25rem',
                  fontSize: '0.9rem',
                  fontWeight: '600',
                  letterSpacing: '0.5px',
                }}>
                  — Главная идея проекта
                </p>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ОСОБЕННОСТИ И ФАКТЫ */}
      <section className="section section-white">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Интересные факты</span>
              <h2>Берёзовский — город первопроходцев</h2>
              <p>Узнайте, что делает историю этого уральского города уникальной</p>
            </div>
          </FadeIn>

          <div className="grid-2">
            {highlights.map((h, i) => {
              const IconComp = h.icon;
              return (
                <FadeIn key={i} delay={i * 100}>
                  <div style={{
                    display: 'flex',
                    gap: '1.5rem',
                    padding: '1.75rem',
                    borderRadius: '12px',
                    border: '1px solid rgba(0,0,0,0.08)',
                    transition: 'all 0.3s',
                    background: 'white',
                    boxShadow: '0 2px 10px rgba(0,0,0,0.04)',
                  }}
                    onMouseEnter={e => {
                      e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.1)';
                      e.currentTarget.style.transform = 'translateY(-3px)';
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.boxShadow = '0 2px 10px rgba(0,0,0,0.04)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <div style={{
                      width: '56px',
                      height: '56px',
                      background: 'linear-gradient(135deg, var(--color-dark-green), var(--color-green))',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'var(--color-gold-light)',
                      flexShrink: 0,
                    }}>
                      <IconComp width={28} height={28} />
                    </div>
                    <div>
                      <h3 style={{ marginBottom: '0.5rem', color: 'var(--color-dark-green)', fontSize: '1.15rem' }}>{h.title}</h3>
                      <p style={{ color: 'var(--color-text-light)', fontSize: '0.95rem', margin: 0, lineHeight: '1.6' }}>{h.text}</p>
                    </div>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* МЕСТА, КОТОРЫЕ СТОИТ УЗНАТЬ */}
      <section className="section section-beige">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Исторические объекты</span>
              <h2>Места, которые стоит узнать</h2>
              <p>
                От знаменитых памятников до малоизвестных уголков города —
                каждое место хранит свою живую историю
              </p>
            </div>
          </FadeIn>

          <div className="grid-4">
            {featured.map((m, i) => (
              <FadeIn key={m.id} delay={i * 100}>
                <MonumentCard monument={m} />
              </FadeIn>
            ))}
          </div>

          <FadeIn>
            <div style={{ textAlign: 'center', marginTop: '3rem' }}>
              <Link to="/monuments" className="btn btn-green">
                <MuseumIcon width={18} height={18} color="white" />
                <span>Все объекты каталога</span>
              </Link>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* БЛОК «ЗНАЕТЕ ЛИ ВЫ?» (С SVG ВМЕСТО СМАЙЛИКОВ) */}
      <section className="section section-dark">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Знаете ли вы?</span>
              <h2 style={{ color: 'white' }}>Факты, которые удивят</h2>
              <p>Малоизвестные исторические страницы первого золотого города России</p>
            </div>
          </FadeIn>

          <div className="grid-3">
            {didYouKnow.map((item, i) => {
              const SvgIcon = item.icon;
              return (
                <FadeIn key={i} delay={i * 100}>
                  <div style={{
                    background: 'rgba(255,255,255,0.05)',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    padding: '2rem',
                    transition: 'all 0.3s',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-start',
                  }}
                    onMouseEnter={e => {
                      e.currentTarget.style.background = 'rgba(255,255,255,0.09)';
                      e.currentTarget.style.transform = 'translateY(-3px)';
                      e.currentTarget.style.borderColor = 'rgba(201,162,39,0.5)';
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)';
                    }}
                  >
                    <div style={{
                      width: '52px',
                      height: '52px',
                      borderRadius: '12px',
                      background: 'rgba(201,162,39,0.15)',
                      border: '1px solid rgba(201,162,39,0.3)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'var(--color-gold-light)',
                      marginBottom: '1.25rem',
                    }}>
                      <SvgIcon width={28} height={28} />
                    </div>
                    <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: '0.95rem', lineHeight: '1.6', margin: 0 }}>
                      {item.text}
                    </p>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* ПРИЗЫВ К ДЕЙСТВИЮ */}
      <section className="section section-white">
        <div className="container">
          <FadeIn>
            <div style={{
              background: 'linear-gradient(135deg, var(--color-dark-green), var(--color-green))',
              borderRadius: '20px',
              padding: '4rem 2rem',
              textAlign: 'center',
              color: 'white',
              boxShadow: '0 10px 40px rgba(0,0,0,0.15)',
            }}>
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: 'rgba(201,162,39,0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 1.5rem',
                color: 'var(--color-gold-light)',
              }}>
                <ShieldIcon width={36} height={36} />
              </div>
              <h2 style={{ marginBottom: '1rem', color: 'white' }}>
                Помоги сохранить историю Берёзовского
              </h2>
              <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: '1.05rem', maxWidth: '620px', margin: '0 auto 2rem', lineHeight: '1.6' }}>
                Знаешь о малоизвестном историческом объекте или памятном месте? Расскажи о нём — вместе мы сохраним
                историю родного города для будущих поколений.
              </p>
              <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
                <Link to="/preserve" className="btn btn-primary">
                  <ScrollIcon width={18} height={18} color="var(--color-dark-green)" />
                  <span>Расскажи о забытом месте</span>
                </Link>
                <Link to="/routes" className="btn btn-outline">
                  <CompassIcon width={18} height={18} color="white" />
                  <span>Исследовать маршруты</span>
                </Link>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
