import { Link } from 'react-router-dom';
import FadeIn from '../components/FadeIn';
import {
  PickaxeIcon,
  FactoryIcon,
  HammersIcon,
  MicroscopeIcon,
  MuseumIcon,
  StarIcon,
  PersonIcon,
  GoldIcon,
  ScrollIcon,
  BookIcon,
  ChurchIcon,
} from '../components/Icons';

const timeline = [
  {
    year: '1745',
    title: 'Открытие золота Ерофеем Марковым',
    text: 'Крестьянин Ерофей Марков из деревни Шарташ нашёл близ нынешнего Берёзовского первое в России рудное золото. Образцы были исследованы на Урале и в Санкт-Петербурге — открытие официально подтверждено.',
    icon: GoldIcon,
  },
  {
    year: '1748',
    title: 'Начало промышленной золотодобычи',
    text: 'На берёзовском месторождении заработала первая в России золотопромывальная фабрика на реке Берёзовке. Началась регулярная государственная добыча золота.',
    icon: FactoryIcon,
  },
  {
    year: '1760-е',
    title: 'Образование Берёзовского завода',
    text: 'Горнопромышленный посёлок при золотом руднике получает официальный статус. Вокруг завода формируется постоянное поселение уральских горняков.',
    icon: HammersIcon,
  },
  {
    year: '1814',
    title: 'Революционное открытие Льва Брусницына',
    text: 'Горный мастер Лев Иванович Брусницын разработал метод промышленной добычи золота из россыпей. Это изобретение совершило переворот в мировой золотодобыче и распространилось по всей планете.',
    icon: MicroscopeIcon,
  },
  {
    year: '1816',
    title: 'Основание Музея золота',
    text: 'При Берёзовском заводе основан минералогический кабинет — один из старейших горнозаводских музеев России, действующий и сегодня.',
    icon: MuseumIcon,
  },
  {
    year: 'XIX век',
    title: 'Расцвет Берёзовских золотых промыслов',
    text: 'Берёзовский становится признанной «золотой столицей» Урала. Действуют десятки шахт, фабрик и старательских артелей.',
    icon: PickaxeIcon,
  },
  {
    year: '1874',
    title: 'Освящение каменной Успенской церкви',
    text: 'На средства горнорабочих и прихожан возведён величественный каменный храм в стиле уральского классицизма, ставший духовным символом города.',
    icon: ChurchIcon,
  },
  {
    year: '1938',
    title: 'Присвоение статуса города',
    text: 'Рабочий посёлок Берёзовский официально преобразован в город. Развивается социальная инфраструктура, строятся новые районы.',
    icon: HammersIcon,
  },
  {
    year: '1941–1945',
    title: 'Великая Отечественная война',
    text: 'Жители города уходят на фронт. Рудники Берёзовского бесперебойно поставляют стратегический металл для обороны страны.',
    icon: StarIcon,
  },
  {
    year: 'Наши дни',
    title: 'Современный город-музей',
    text: 'Берёзовский сохраняет непрерывную добычу золота уже свыше 275 лет. Развиваются туризм, краеведение и музейные маршруты.',
    icon: ScrollIcon,
  },
];

const persons = [
  {
    name: 'Ерофей Сидорович Марков',
    years: 'XVIII век (ок. 1700 — после 1745)',
    icon: PersonIcon,
    desc: 'Крестьянин деревни Шарташ, открывший в 1745 году первое в России рудное золото. Находка кварца с крупицами золота положила начало всей российской золотодобывающей промышленности.',
  },
  {
    name: 'Лев Иванович Брусницын',
    years: '1784 — 1857',
    icon: MicroscopeIcon,
    desc: 'Выдающийся уральский горный мастер и изобретатель. В 1814 году открыл и научно обосновал россыпное золото на Урале, сконструировал промывочные машины, изменившие мировую золотодобычу.',
  },
  {
    name: 'Уральские горщики и старатели',
    years: 'XVIII — XXI века',
    icon: HammersIcon,
    desc: 'Поколения потомственных мастеров, геологов и шахтёров, которые создавали технологическую славу Берёзовского рудника и открыли более 140 уникальных минералов.',
  },
];

const periods = [
  {
    title: 'Зарождение поселения и открытие золота (до 1748 г.)',
    content: `История Берёзовского неразрывно связана с историей открытия золота в России. До середины XVIII века Россия не имела собственных разведанных месторождений золота и закупала драгоценные металлы за границей.

Весной 1745 года крестьянин деревни Шарташ Ерофей Марков нашёл в лесу близ реки Берёзовки куски кварца с золотыми искрами. Образцы прошли строгую пробу в Екатеринбургской горной канцелярии и Санкт-Петербургской Берг-коллегии. Открытие подтвердилось: в России есть своё золото!`,
  },
  {
    title: 'Развитие казённой золотодобычи (1748 — начало XIX в.)',
    content: `В 1748 году на месте находки Маркова была сооружена плотина на реке Берёзовке и построена первая золотопромывальная фабрика. Вокруг предприятия вырос горнозаводской посёлок.

Берёзовские рудники находились в прямом ведении казны, а добытый металл направлялся на Монетный двор. К концу XVIII века Берёзовский стал ключевым горнорудным районом Российской империи.`,
  },
  {
    title: 'Эпоха россыпного золота и расцвет (XIX век)',
    content: `В 1814 году смотритель Берёзовских промыслов Лев Брусницын совершил открытие мирового масштаба: доказал промышленную ценность россыпного золота в речных долинах и разработал систему промывки песков на вашгердах и вашгердных фабриках.

Открытие Брусницына вызвало стремительный рост добычи золота на Урале и в Сибири, а его методики позже использовались на приисках Калифорнии и Австралии. В 1816 году в Берёзовском создаётся один из старейших в стране музеев золота.`,
  },
  {
    title: 'Советский период и годы войны (XX век)',
    content: `После революции предприятия были реорганизованы в трест «Уралзолото». Добыча была модернизирована, построены глубокие шахтные стволы («Южная», «Северная»).

В 1938 году рабочий посёлок получил статус города. В годы Великой Отечественной войны горняки Берёзовского обеспечивали золотой запас страны, а свыше 3000 жителей города отдали жизни в боях за свободу Родины.`,
  },
  {
    title: 'Берёзовский сегодня: память и сохранение наследия',
    content: `Сегодня Берёзовский — динамичный уральский город с населением свыше 60 тысяч человек. Добыча золота на Берёзовском руднике продолжается — рудник признан старейшим действующим в мире.

Вместе с тем город бережно хранит историческую память: открыты Музей золота, туристическая шахта, восстанавливаются памятники и разрабатываются краеведческие маршруты для школьников и гостей Урала.`,
  },
];

export default function HistoryPage() {
  return (
    <>
      {/* Шапка */}
      <div style={{
        background: 'linear-gradient(135deg, var(--color-dark-green), #0d3320)',
        paddingTop: '70px',
        padding: '120px 2rem 3rem',
        color: 'white',
      }}>
        <div className="container">
          <div className="breadcrumb">
            <Link to="/">Главная</Link>
            <span className="breadcrumb-sep">›</span>
            <span>История города</span>
          </div>
          <h1>История Берёзовского</h1>
          <p style={{ color: 'rgba(255,255,255,0.75)', marginTop: '0.75rem', fontSize: '1.05rem' }}>
            От первой золотой находки 1745 года до наших дней — 275 лет уральской горнозаводской славы
          </p>
        </div>
      </div>

      {/* Периоды истории */}
      <section className="section section-beige">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Периоды истории</span>
              <h2>Летопись города по эпохам</h2>
              <p>Берёзовский прошёл путь от лесного урочища до признанной столицы уральского золота</p>
            </div>
          </FadeIn>

          {periods.map((period, i) => (
            <FadeIn key={i} delay={i * 80}>
              <div style={{
                background: 'white',
                borderRadius: '14px',
                padding: '2.25rem',
                marginBottom: '1.75rem',
                boxShadow: '0 2px 15px rgba(0,0,0,0.05)',
              }}>
                <div style={{
                  display: 'inline-block',
                  background: 'var(--color-gold)',
                  color: 'var(--color-dark-green)',
                  padding: '0.35rem 1.1rem',
                  borderRadius: '50px',
                  fontSize: '0.85rem',
                  fontWeight: '700',
                  marginBottom: '1.25rem',
                }}>
                  {period.title}
                </div>
                {period.content.split('\n\n').map((para, j) => (
                  <p key={j} style={{ color: 'var(--color-text)', lineHeight: '1.85', fontSize: '1.02rem', margin: '0 0 1rem 0' }}>
                    {para}
                  </p>
                ))}
              </div>
            </FadeIn>
          ))}
        </div>
      </section>

      {/* Временная шкала */}
      <section className="section section-white">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Хронология</span>
              <h2>Ключевые даты и вехи</h2>
              <p>Важнейшие события, определившие судьбу города и золотодобычи России</p>
            </div>
          </FadeIn>

          <div className="timeline">
            {timeline.map((item, i) => {
              const EventIcon = item.icon;
              return (
                <FadeIn key={i} delay={i * 80}>
                  <div className="timeline-item">
                    <div className="timeline-dot" style={{ background: i % 2 === 0 ? 'var(--color-gold)' : 'var(--color-green)' }} />
                    <div className="timeline-content">
                      <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', marginBottom: '0.75rem' }}>
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '50%',
                          background: 'rgba(201,162,39,0.15)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: 'var(--color-gold)',
                          flexShrink: 0,
                        }}>
                          <EventIcon width={20} height={20} />
                        </div>
                        <span className="timeline-year">{item.year}</span>
                      </div>
                      <div className="timeline-title">{item.title}</div>
                      <div className="timeline-text">{item.text}</div>
                    </div>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* Исторические личности */}
      <section className="section section-beige">
        <div className="container">
          <FadeIn>
            <div className="section-header">
              <span className="section-tag">Исторические личности</span>
              <h2>Люди, вписавшие Берёзовский в историю</h2>
              <p>Те, кто своим трудом и открытиями прославил уральский край на весь мир</p>
            </div>
          </FadeIn>

          <div className="grid-3">
            {persons.map((p, i) => {
              const PersonIconComp = p.icon;
              return (
                <FadeIn key={i} delay={i * 120}>
                  <div className="person-card">
                    <div className="person-avatar" style={{ color: 'var(--color-gold-light)' }}>
                      <PersonIconComp width={36} height={36} />
                    </div>
                    <div className="person-name">{p.name}</div>
                    <div className="person-years">{p.years}</div>
                    <div className="person-desc" style={{ lineHeight: '1.6' }}>{p.desc}</div>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* Рекомендуемая литература */}
      <section className="section section-dark">
        <div className="container">
          <FadeIn>
            <h2 style={{ color: 'white', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <BookIcon width={28} height={28} color="var(--color-gold-light)" />
              <span>Источники и краеведческая литература</span>
            </h2>
            <div className="grid-2">
              {[
                { title: 'Музей истории золотодобывающей промышленности Урала', desc: 'Фондовые коллекции, исторические документы и монографии музея.' },
                { title: 'Официальный портал города Берёзовский', desc: 'Официальные данные Администрации Берёзовского городского округа.' },
                { title: 'Реестр объектов культурного наследия Свердловской области', desc: 'Государственные охранные реестры памятников истории и архитектуры.' },
                { title: 'Труды Уральского геологического музея и УОЛЕ', desc: 'Научные труды по минералогии и истории Берёзовского месторождения.' },
              ].map((src, i) => (
                <div key={i} style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  padding: '1.5rem',
                }}>
                  <h4 style={{ color: 'var(--color-gold-light)', marginBottom: '0.5rem', fontSize: '1rem' }}>
                    {src.title}
                  </h4>
                  <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.88rem', margin: 0, lineHeight: '1.5' }}>{src.desc}</p>
                </div>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
