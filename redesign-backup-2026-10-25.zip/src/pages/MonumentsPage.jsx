import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { monuments, categories } from '../data/monuments';
import MonumentCard from '../components/MonumentCard';
import FadeIn from '../components/FadeIn';
import {
  SearchIcon,
  HammersIcon,
  MonumentIcon,
  ChurchIcon,
  MuseumIcon,
  StarIcon,
  HiddenPlaceIcon,
  ScrollIcon,
  ParkIcon,
} from '../components/Icons';

const iconMap = {
  all: HammersIcon,
  monument: MonumentIcon,
  architecture: ChurchIcon,
  museum: MuseumIcon,
  memorial: StarIcon,
  leisure: ParkIcon,
  hidden: HiddenPlaceIcon,
};

export default function MonumentsPage() {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [filtered, setFiltered] = useState(monuments);
  const [sort, setSort] = useState('default');

  useEffect(() => {
    let result = monuments;

    // Фильтр по категории
    if (activeCategory !== 'all') {
      result = result.filter(m => m.category === activeCategory);
    }

    // Фильтр по поиску
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(m =>
        m.name.toLowerCase().includes(q) ||
        m.shortDesc.toLowerCase().includes(q) ||
        m.address.toLowerCase().includes(q)
      );
    }

    // Сортировка
    if (sort === 'name') {
      result = [...result].sort((a, b) => a.name.localeCompare(b.name, 'ru'));
    } else if (sort === 'year') {
      result = [...result].sort((a, b) => {
        const ya = parseInt(a.yearBuilt) || 9999;
        const yb = parseInt(b.yearBuilt) || 9999;
        return ya - yb;
      });
    }

    setFiltered(result);
  }, [search, activeCategory, sort]);

  return (
    <>
      {/* Hero-шапка */}
      <div style={{
        background: 'linear-gradient(135deg, var(--color-dark-green), #0d3320)',
        paddingTop: '70px',
        padding: '120px 2rem 3rem',
        color: 'white',
      }}>
        <div className="container">
          <div className="breadcrumb">
            <Link to="/">Главная</Link>
            <span className="breadcrumb-sep">›</span>
            <span>Памятники</span>
          </div>
          <h1>Памятники и достопримечательности</h1>
          <p style={{ color: 'rgba(255,255,255,0.75)', marginTop: '0.75rem', fontSize: '1.05rem' }}>
            Исторические объекты Берёзовского: от знаменитых памятников до малоизвестных мест
          </p>
        </div>
      </div>

      <section className="section section-beige" style={{ paddingTop: '3rem' }}>
        <div className="container">

          {/* Поиск и сортировка */}
          <div className="search-bar">
            <div className="search-input-wrap">
              <span className="search-icon" style={{ display: 'flex', alignItems: 'center' }}>
                <SearchIcon width={18} height={18} color="var(--color-text-light)" />
              </span>
              <input
                type="text"
                className="search-input"
                placeholder="Поиск по названию, адресу или описанию..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
            <select
              value={sort}
              onChange={e => setSort(e.target.value)}
              style={{
                padding: '0.75rem 1.25rem',
                border: '2px solid #e0e0e0',
                borderRadius: '50px',
                fontSize: '0.9rem',
                outline: 'none',
                cursor: 'pointer',
                background: 'white',
                minWidth: '180px',
                color: 'var(--color-text)',
                fontWeight: '500',
              }}
            >
              <option value="default">По умолчанию</option>
              <option value="name">По названию А–Я</option>
              <option value="year">По дате постройки</option>
            </select>
          </div>

          {/* Категории с SVG иконками */}
          <div className="filter-tabs">
            {categories.map(cat => {
              const IconComp = iconMap[cat.id] || HammersIcon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  className={`filter-tab${isActive ? ' active' : ''}`}
                  onClick={() => setActiveCategory(cat.id)}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}
                >
                  <IconComp width={16} height={16} color={isActive ? 'white' : 'var(--color-green)'} />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* Результаты */}
          <div style={{ marginBottom: '1.5rem', color: 'var(--color-text-light)', fontSize: '0.9rem' }}>
            Найдено объектов: <strong>{filtered.length}</strong>
          </div>

          {filtered.length > 0 ? (
            <div className="grid-3">
              {filtered.map((m, i) => (
                <FadeIn key={m.id} delay={i * 80}>
                  <MonumentCard monument={m} />
                </FadeIn>
              ))}
            </div>
          ) : (
            <div style={{
              textAlign: 'center',
              padding: '4rem',
              color: 'var(--color-text-light)',
            }}>
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: 'rgba(0,0,0,0.05)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 1.5rem',
                color: 'var(--color-text-light)',
              }}>
                <SearchIcon width={32} height={32} />
              </div>
              <h3>Ничего не найдено</h3>
              <p>Попробуйте изменить поисковый запрос или фильтр</p>
              <button
                className="btn btn-green"
                style={{ marginTop: '1rem' }}
                onClick={() => { setSearch(''); setActiveCategory('all'); }}
              >
                Сбросить фильтры
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Блок малоизвестные */}
      <section className="section section-dark">
        <div className="container" style={{ textAlign: 'center' }}>
          <FadeIn>
            <div style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              background: 'rgba(201,162,39,0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1.5rem',
              color: 'var(--color-gold-light)',
            }}>
              <HiddenPlaceIcon width={32} height={32} />
            </div>
            <h2 style={{ color: 'white', marginBottom: '1rem' }}>
              Знаешь малоизвестное историческое место?
            </h2>
            <p style={{ color: 'rgba(255,255,255,0.7)', maxWidth: '520px', margin: '0 auto 2rem', fontSize: '1.05rem', lineHeight: '1.6' }}>
              Расскажи о нём — и мы добавим его в каталог сайта. Вместе мы сохраним
              историю Берёзовского для будущих поколений.
            </p>
            <Link to="/preserve" className="btn btn-primary">
              <ScrollIcon width={18} height={18} color="var(--color-dark-green)" />
              <span>Рассказать о месте</span>
            </Link>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
