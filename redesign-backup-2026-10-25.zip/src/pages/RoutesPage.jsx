import { useState } from 'react';
import { Link } from 'react-router-dom';
import YandexRouteMap from '../components/YandexRouteMap';
import FadeIn from '../components/FadeIn';
import { useUserLocation, calculateDistance, formatDistance } from '../utils/useUserLocation';
import {
  CompassIcon,
  ClockIcon,
  FootstepsIcon,
  MapPinIcon,
  NatureIcon,
  MuseumIcon,
  ShieldIcon,
} from '../components/Icons';

const routes = [
  {
    id: 1,
    number: 'Маршрут №1',
    name: 'Золотая история Берёзовского',
    desc: 'Главный исторический пешеходный маршрут города: от памятника первооткрывателю Маркову к старейшему Музею золота, историческому храму и Парку Победы.',
    duration: '2–2,5 часа',
    distance: '~3,2 км',
    difficulty: 'Лёгкий пеший',
    color: '#c9a227',
    stops: [
      {
        num: 1,
        name: 'Памятник Ерофею Маркову',
        desc: 'Начало маршрута на площади Первооткрывателей. Памятник открывателю первого рудного золота в России (1745 год).',
        coords: [56.91185, 60.80410],
      },
      {
        num: 2,
        name: 'Музей истории золотодобывающей промышленности',
        desc: 'Один из старейших музеев горного дела в России (основан в 1816 году, ул. Коммуны, 45). Редчайшие коллекции золота.',
        coords: [56.91275, 60.80184],
      },
      {
        num: 3,
        name: 'Церковь Успения Богородицы',
        desc: 'Старинный каменный классический храм XIX века, возведённый на средства уральских старателей (Клубный пер., 1).',
        coords: [56.91151, 60.80649],
      },
      {
        num: 4,
        name: 'Мемориал воинской доблести в Парке Победы',
        desc: 'Величественный мемориал и Вечный огонь в честь берёзовчан, павших в годы Великой Отечественной войны.',
        coords: [56.90976, 60.81214],
      },
    ],
  },
  {
    id: 2,
    number: 'Маршрут №2',
    name: 'Парки, природа и зоны отдыха',
    desc: 'Оздоровительная и видовая прогулка: от Исторического сквера через центральный Парк Победы и реликтовый бор Тропы здоровья к Шиловскому пруду.',
    duration: '2,5–3 часа',
    distance: '~4,5 км',
    difficulty: 'Прогулочный / Велосипедный',
    color: '#2d6a4f',
    stops: [
      {
        num: 1,
        name: 'Исторический сквер у реки Берёзовки',
        desc: 'Тенистая прогулочная зона вдоль русла реки Берёзовки с вековыми лиственницами.',
        coords: [56.90680, 60.80450],
      },
      {
        num: 2,
        name: 'Парк Победы',
        desc: 'Центральный парк с аллеями, военной техникой, скейт-парком и детскими городками.',
        coords: [56.90976, 60.81214],
      },
      {
        num: 3,
        name: '«Тропа здоровья» в сосновом бору',
        desc: 'Благоустроенная освещённая лесная трасса для пеших прогулок, бега и скандинавской ходьбы.',
        coords: [56.91443, 60.82397],
      },
      {
        num: 4,
        name: 'Шиловский пруд',
        desc: 'Главный живописный водоём города: сосновый берег, пляжные зоны, рыбалка и зеркальная гладь воды.',
        coords: [56.92415, 60.86453],
      },
    ],
  },
  {
    id: 3,
    number: 'Маршрут №3',
    name: 'Культура, театр и активный спорт',
    desc: 'Маршрут по главным культурным и спортивным точкам города: от Музея золота к главной театральной сцене ДК «Современник» и парку «Гора Лиственная».',
    duration: '3–4 часа',
    distance: '~7 км (пешком + транспорт)',
    difficulty: 'Познавательный',
    color: '#856404',
    stops: [
      {
        num: 1,
        name: 'Музей золота Урала',
        desc: 'Погружение в культуру горного дела и старательские традиции города.',
        coords: [56.91275, 60.80184],
      },
      {
        num: 2,
        name: 'Дворец культуры «Современник»',
        desc: 'Главный театрально-концертный зал Берёзовского: спектакли, кинопоказы и фестивали.',
        coords: [56.90194, 60.74754],
      },
      {
        num: 3,
        name: 'Парк отдыха «Гора Лиственная»',
        desc: 'Всесезонный спортивно-развлекательный парк: смотровые площадки, тюбинг, лыжные трассы и экотропы.',
        coords: [56.94025, 60.73656],
      },
    ],
  },
];

export default function RoutesPage() {
  const { location: userLocation, loading: geoLoading, error: geoError, requestLocation } = useUserLocation();

  return (
    <>
      {/* Шапка */}
      <div style={{
        background: 'linear-gradient(135deg, var(--color-dark-green), #0d3320)',
        paddingTop: '70px',
        padding: '120px 2rem 3rem',
        color: 'white',
      }}>
        <div className="container">
          <div className="breadcrumb">
            <Link to="/">Главная</Link>
            <span className="breadcrumb-sep">›</span>
            <span>Маршруты</span>
          </div>
          <h1>Туристические и прогулочные маршруты</h1>
          <p style={{ color: 'rgba(255,255,255,0.75)', marginTop: '0.75rem', fontSize: '1.05rem' }}>
            Пешеходные маршруты по городу Берёзовскому с настоящей навигацией на Яндекс Картах
          </p>
        </div>
      </div>

      <section className="section section-beige" style={{ paddingTop: '2.5rem' }}>
        <div className="container">

          {/* Плашка с геолокацией пользователя */}
          <FadeIn>
            <div style={{
              background: 'white',
              borderRadius: '14px',
              padding: '1.25rem 1.75rem',
              marginBottom: '2rem',
              boxShadow: '0 3px 15px rgba(0,0,0,0.06)',
              border: '1px solid #e0e0e0',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '1rem',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{
                  width: '42px',
                  height: '42px',
                  borderRadius: '50%',
                  background: userLocation ? 'rgba(45,106,79,0.1)' : 'rgba(252,63,29,0.1)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: userLocation ? 'var(--color-green)' : '#fc3f1d',
                  flexShrink: 0,
                }}>
                  <MapPinIcon width={22} height={22} />
                </div>
                <div>
                  <div style={{ fontWeight: '700', fontSize: '0.95rem', color: 'var(--color-dark-green)' }}>
                    {userLocation ? 'Ваше местоположение определено' : 'Построить маршрут от вашего текущего местоположения'}
                  </div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--color-text-light)' }}>
                    {userLocation
                      ? `Координаты: ${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)} · Маршруты будут строиться прямо от вас!`
                      : 'Разрешите доступ к геопозиции, чтобы сайт проложил точный путь от вас к началу прогулки'}
                  </div>
                  {geoError && (
                    <div style={{ fontSize: '0.8rem', color: '#dc3545', marginTop: '2px' }}>
                      {geoError}
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={requestLocation}
                disabled={geoLoading}
                className="btn btn-sm"
                style={{
                  background: userLocation ? '#2d6a4f' : '#fc3f1d',
                  color: 'white',
                  borderRadius: '50px',
                  padding: '0.55rem 1.4rem',
                  fontWeight: '600',
                  fontSize: '0.88rem',
                  border: 'none',
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                }}
              >
                <span>{geoLoading ? 'Определение...' : userLocation ? 'Обновить мою геопозицию' : 'Определить где я'}</span>
              </button>
            </div>
          </FadeIn>

          {/* Список маршрутов с Яндекс Картами */}
          {routes.map((route, ri) => {
            // Расчёт расстояния от пользователя до первой остановки маршрута
            let distanceInfo = null;
            if (userLocation) {
              const startCoords = route.stops[0].coords;
              const dist = calculateDistance(userLocation.lat, userLocation.lng, startCoords[0], startCoords[1]);
              distanceInfo = formatDistance(dist);
            }

            // Формирование ссылки для Яндекс Карт:
            // Если есть геопозиция пользователя, строим ОТ НЕГО
            const yandexFromTo = userLocation
              ? `${userLocation.lat}%2C${userLocation.lng}~` + route.stops.map(s => `${s.coords[0]}%2C${s.coords[1]}`).join('~')
              : route.stops.map(s => `${s.coords[0]}%2C${s.coords[1]}`).join('~');

            const googleFromTo = userLocation
              ? `${userLocation.lat},${userLocation.lng}/` + route.stops.map(s => `${s.coords[0]},${s.coords[1]}`).join('/')
              : route.stops.map(s => `${s.coords[0]},${s.coords[1]}`).join('/');

            return (
              <FadeIn key={route.id} delay={ri * 100}>
                <div className="route-card" style={{ marginBottom: '2.5rem' }}>
                  <div className="route-header" style={{
                    background: route.color !== '#c9a227'
                      ? `linear-gradient(135deg, ${route.color}, ${route.color}ee)`
                      : 'linear-gradient(135deg, #1a4731, #0d3320)',
                    borderBottom: '3px solid var(--color-gold)'
                  }}>
                    <div className="route-number">{route.number}</div>
                    <div className="route-name">«{route.name}»</div>
                    <div className="route-meta">
                      <span className="route-meta-item">
                        <ClockIcon width={16} height={16} color="var(--color-gold-light)" />
                        <span>{route.duration}</span>
                      </span>
                      <span className="route-meta-item">
                        <FootstepsIcon width={16} height={16} color="var(--color-gold-light)" />
                        <span>{route.distance}</span>
                      </span>
                      <span className="route-meta-item">
                        <NatureIcon width={16} height={16} color="var(--color-gold-light)" />
                        <span>{route.difficulty}</span>
                      </span>
                      <span className="route-meta-item">
                        <MapPinIcon width={16} height={16} color="var(--color-gold-light)" />
                        <span>{route.stops.length} остановки</span>
                      </span>
                    </div>
                  </div>

                  <div className="route-body">
                    <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: '2rem', alignItems: 'start' }}>
                      {/* Описание и остановки */}
                      <div>
                        <p style={{ color: 'var(--color-text-light)', marginBottom: '1.25rem', fontSize: '0.98rem', lineHeight: '1.6' }}>
                          {route.desc}
                        </p>

                        {/* Плашка расстояния от пользователя */}
                        {distanceInfo && (
                          <div style={{
                            background: 'rgba(45,106,79,0.08)',
                            border: '1px solid rgba(45,106,79,0.2)',
                            borderRadius: '10px',
                            padding: '0.75rem 1rem',
                            marginBottom: '1.25rem',
                            fontSize: '0.88rem',
                            color: 'var(--color-dark-green)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                          }}>
                            <span style={{ fontSize: '1.2rem' }}>🚶</span>
                            <span>Вы находитесь в <strong>{distanceInfo.text}</strong> от начала этого маршрута ({distanceInfo.walkTime})</span>
                          </div>
                        )}

                        <h4 style={{ marginBottom: '1rem', color: 'var(--color-dark-green)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <MapPinIcon width={18} height={18} color="var(--color-green)" />
                          <span>Последовательность остановок:</span>
                        </h4>

                        <ul className="route-stops">
                          {route.stops.map(stop => (
                            <li key={stop.num}>
                              <div className="stop-number" style={{ background: route.color !== '#c9a227' ? route.color : 'var(--color-gold)' }}>
                                {stop.num}
                              </div>
                              <div className="stop-info">
                                <h4>{stop.name}</h4>
                                <p>{stop.desc}</p>
                              </div>
                            </li>
                          ))}
                        </ul>

                        {/* Кнопки вызова реальной навигации */}
                        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', marginTop: '1.25rem' }}>
                          <a
                            href={`https://yandex.ru/maps/?rtext=${yandexFromTo}&rtt=pd`}
                            target="_blank"
                            rel="noreferrer"
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '8px',
                              background: '#fc3f1d',
                              color: 'white',
                              padding: '0.6rem 1.3rem',
                              borderRadius: '50px',
                              fontSize: '0.88rem',
                              fontWeight: '700',
                              textDecoration: 'none',
                              boxShadow: '0 3px 10px rgba(252,63,29,0.3)',
                            }}
                          >
                            <span>Маршрут в Яндекс Картах</span>
                          </a>

                          <a
                            href={`https://www.google.com/maps/dir/${googleFromTo}`}
                            target="_blank"
                            rel="noreferrer"
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '8px',
                              background: '#e8f0fe',
                              border: '1px solid #d2e3fc',
                              color: '#1a73e8',
                              padding: '0.6rem 1.3rem',
                              borderRadius: '50px',
                              fontSize: '0.88rem',
                              fontWeight: '700',
                              textDecoration: 'none',
                            }}
                          >
                            <span>В Google Maps</span>
                          </a>
                        </div>
                      </div>

                      {/* Интерактивная Яндекс Карта маршрута */}
                      <div>
                        <div style={{ marginBottom: '8px', fontSize: '0.82rem', color: '#666', display: 'flex', justifyContent: 'space-between' }}>
                          <span>🗺️ Яндекс Карта маршрута (пешком)</span>
                          <span>Увеличение масштаба колесиком / жестом</span>
                        </div>
                        <YandexRouteMap
                          stops={route.stops}
                          routeColor={route.color}
                          height="360px"
                          userLocation={userLocation}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </FadeIn>
            );
          })}

          {/* Рекомендации */}
          <FadeIn>
            <div style={{
              background: 'linear-gradient(135deg, var(--color-dark-green), #0d3320)',
              borderRadius: '16px',
              padding: '2.5rem',
              color: 'white',
              boxShadow: '0 5px 25px rgba(0,0,0,0.1)',
            }}>
              <h3 style={{ color: 'var(--color-gold-light)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
                <ShieldIcon width={24} height={24} color="var(--color-gold-light)" />
                <span>Советы перед началом прогулки</span>
              </h3>
              <div className="grid-2">
                {[
                  { icon: CompassIcon, tip: 'Нажмите «Определить где я» — и карта покажет, сколько времени вам идти до ближайшей остановки.' },
                  { icon: NatureIcon, tip: 'Маршруты №1 и №2 проходят по удобным тротуарам и пешеходным парковым дорожкам города.' },
                  { icon: MuseumIcon, tip: 'Для посещения Музея золота и шахты-музея уточняйте часы работы на их страницах.' },
                  { icon: ShieldIcon, tip: 'Соблюдайте чистоту на природных объектах у Шиловского пруда и на Тропе здоровья.' },
                ].map((item, i) => {
                  const TipIcon = item.icon;
                  return (
                    <div key={i} style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                      <div style={{
                        width: '42px',
                        height: '42px',
                        borderRadius: '10px',
                        background: 'rgba(201,162,39,0.2)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'var(--color-gold-light)',
                        flexShrink: 0,
                      }}>
                        <TipIcon width={22} height={22} />
                      </div>
                      <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: '0.92rem', margin: 0, lineHeight: '1.5' }}>{item.tip}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
