import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import YandexMiniMap from '../components/YandexMiniMap';
import { getMonumentById, monuments, categories } from '../data/monuments';
import FadeIn from '../components/FadeIn';
import { useUserLocation, calculateDistance, formatDistance } from '../utils/useUserLocation';
import {
  MapPinIcon,
  CalendarIcon,
  ShieldIcon,
  ScrollIcon,
  CompassIcon,
  ChurchIcon,
  MuseumIcon,
  MonumentIcon,
  StarIcon,
  HiddenPlaceIcon,
  HammersIcon,
  BookIcon,
  ParkIcon,
} from '../components/Icons';

const iconMap = {
  all: HammersIcon,
  monument: MonumentIcon,
  architecture: ChurchIcon,
  museum: MuseumIcon,
  memorial: StarIcon,
  leisure: ParkIcon,
  hidden: HiddenPlaceIcon,
};

export default function MonumentDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const monument = getMonumentById(id);
  const [imgError, setImgError] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activeSlide, setActiveSlide] = useState(0);

  const { location: userLocation, loading: geoLoading, requestLocation } = useUserLocation();

  useEffect(() => {
    setActiveSlide(0);
    setImgError(false);
    if (monument) {
      document.title = `${monument.name} — Неизвестный Берёзовский`;
    }
    return () => { document.title = 'Неизвестный Берёзовский'; };
  }, [id, monument]);

  const slides = monument?.images && monument.images.length > 0
    ? monument.images
    : (monument ? [{ url: monument.image, title: monument.name, desc: monument.significance || '' }] : []);

  const currentSlide = slides[activeSlide] || slides[0] || { url: monument?.image, title: monument?.name };

  const nextSlide = () => setActiveSlide((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setActiveSlide((prev) => (prev - 1 + slides.length) % slides.length);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (slides.length > 1) {
        if (e.key === 'ArrowRight') nextSlide();
        if (e.key === 'ArrowLeft') prevSlide();
      }
      if (e.key === 'Escape') setLightboxOpen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [slides.length]);

  if (!monument) {
    return (
      <div style={{ paddingTop: '70px', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '1rem' }}>
        <MuseumIcon width={64} height={64} color="var(--color-dark-green)" />
        <h2>Объект не найден</h2>
        <button className="btn btn-green" onClick={() => navigate('/monuments')}>← Назад к памятникам</button>
      </div>
    );
  }

  const cat = categories.find(c => c.id === monument.category);
  const CatIcon = iconMap[monument.category] || MonumentIcon;
  const related = monuments.filter(m => m.category === monument.category && m.id !== monument.id).slice(0, 3);
  const routeUrl = `https://www.openstreetmap.org/directions?from=&to=${monument.lat}%2C${monument.lng}&type=foot`;

  return (
    <>
      {/* Герой-шапка */}
      <div className="monument-hero">
        {!imgError && (
          <div
            className="monument-hero-bg"
            style={{ backgroundImage: `url(${currentSlide.url || monument.image})` }}
          />
        )}
        <div className="monument-hero-overlay" />
        <div className="monument-hero-content">
          <div className="container">
            <div className="breadcrumb">
              <Link to="/">Главная</Link>
              <span className="breadcrumb-sep">›</span>
              <Link to="/monuments">Памятники</Link>
              <span className="breadcrumb-sep">›</span>
              <span>{monument.name}</span>
            </div>

            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              background: 'rgba(201,162,39,0.2)',
              border: '1px solid var(--color-gold)',
              color: 'var(--color-gold-light)',
              padding: '0.4rem 1.1rem',
              borderRadius: '50px',
              fontSize: '0.85rem',
              marginBottom: '1rem',
            }}>
              <CatIcon width={16} height={16} color="var(--color-gold-light)" />
              <span>{cat?.label || monument.category}</span>
            </div>

            <h1 style={{ marginBottom: '1rem' }}>{monument.name}</h1>
            <p style={{
              color: 'rgba(255,255,255,0.85)',
              fontSize: '1.05rem',
              maxWidth: '650px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
            }}>
              <MapPinIcon width={18} height={18} color="var(--color-gold-light)" />
              <span>{monument.address}</span>
            </p>

            {monument.status && (
              <div style={{
                marginTop: '1rem',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                background: 'rgba(255,255,255,0.12)',
                padding: '0.4rem 1.1rem',
                borderRadius: '50px',
                fontSize: '0.85rem',
                color: 'white',
                backdropFilter: 'blur(5px)',
              }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#40916c' }} />
                <span>{monument.status}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Контент */}
      <section className="section section-beige" style={{ paddingTop: '3rem' }}>
        <div className="container">
          <div className="object-detail-grid">
            {/* Основной контент */}
            <div>
              {/* Фотография / Слайдер объекта — ПОЛНОЕ ОТОБРАЖЕНИЕ БЕЗ ОБРЕЗКИ */}
              <FadeIn>
                <div style={{
                  borderRadius: '16px',
                  overflow: 'hidden',
                  marginBottom: '2rem',
                  boxShadow: '0 8px 30px rgba(0,0,0,0.12)',
                  background: '#0d2b1d',
                  border: '1px solid rgba(201,162,39,0.2)',
                  position: 'relative',
                }}>
                  {!imgError ? (
                    <div
                      style={{
                        position: 'relative',
                        width: '100%',
                        minHeight: '440px',
                        maxHeight: '620px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        overflow: 'hidden',
                        cursor: 'zoom-in',
                        background: 'linear-gradient(135deg, #0d2b1d, #1a4731)',
                      }}
                      onClick={() => setLightboxOpen(true)}
                      title="Нажмите, чтобы открыть фото во весь экран"
                    >
                      {/* Мягкий размытый фон из текущего слайда */}
                      <div
                        key={`bg-${activeSlide}`}
                        style={{
                          position: 'absolute',
                          inset: '-20px',
                          backgroundImage: `url(${currentSlide.url})`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center',
                          filter: 'blur(25px) brightness(0.4)',
                          opacity: 0.8,
                          transform: 'scale(1.1)',
                          transition: 'background-image 0.4s ease',
                        }}
                      />

                      {/* Основное фото В ПОЛНЫЙ РОСТ И БЕЗ ОБРЕЗКИ */}
                      <img
                        key={`img-${activeSlide}`}
                        src={currentSlide.url}
                        alt={currentSlide.title || monument.name}
                        style={{
                          position: 'relative',
                          zIndex: 2,
                          maxWidth: '100%',
                          maxHeight: '580px',
                          width: 'auto',
                          height: 'auto',
                          objectFit: 'contain',
                          display: 'block',
                          boxShadow: '0 5px 25px rgba(0,0,0,0.4)',
                          borderRadius: '8px',
                          transition: 'transform 0.3s ease',
                        }}
                        onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.015)'}
                        onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
                        onError={() => setImgError(true)}
                      />

                      {/* Кнопки перелистывания слайдов */}
                      {slides.length > 1 && (
                        <>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              prevSlide();
                            }}
                            style={{
                              position: 'absolute',
                              left: '16px',
                              top: '50%',
                              transform: 'translateY(-50%)',
                              zIndex: 4,
                              background: 'rgba(26,71,49,0.85)',
                              border: '1px solid var(--color-gold)',
                              color: 'white',
                              width: '46px',
                              height: '46px',
                              borderRadius: '50%',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              cursor: 'pointer',
                              fontSize: '1.4rem',
                              backdropFilter: 'blur(4px)',
                              boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={e => {
                              e.currentTarget.style.background = 'var(--color-gold)';
                              e.currentTarget.style.color = '#0d2b1d';
                            }}
                            onMouseLeave={e => {
                              e.currentTarget.style.background = 'rgba(26,71,49,0.85)';
                              e.currentTarget.style.color = 'white';
                            }}
                            title="Предыдущее фото"
                          >
                            ‹
                          </button>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              nextSlide();
                            }}
                            style={{
                              position: 'absolute',
                              right: '16px',
                              top: '50%',
                              transform: 'translateY(-50%)',
                              zIndex: 4,
                              background: 'rgba(26,71,49,0.85)',
                              border: '1px solid var(--color-gold)',
                              color: 'white',
                              width: '46px',
                              height: '46px',
                              borderRadius: '50%',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              cursor: 'pointer',
                              fontSize: '1.4rem',
                              backdropFilter: 'blur(4px)',
                              boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={e => {
                              e.currentTarget.style.background = 'var(--color-gold)';
                              e.currentTarget.style.color = '#0d2b1d';
                            }}
                            onMouseLeave={e => {
                              e.currentTarget.style.background = 'rgba(26,71,49,0.85)';
                              e.currentTarget.style.color = 'white';
                            }}
                            title="Следующее фото"
                          >
                            ›
                          </button>

                          {/* Счётчик слайдов */}
                          <div style={{
                            position: 'absolute',
                            top: '16px',
                            left: '16px',
                            zIndex: 3,
                            background: 'rgba(13,43,29,0.85)',
                            border: '1px solid var(--color-gold)',
                            color: 'var(--color-gold-light)',
                            padding: '6px 14px',
                            borderRadius: '50px',
                            fontSize: '0.82rem',
                            fontWeight: '700',
                            backdropFilter: 'blur(6px)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                          }}>
                            <span>📸</span>
                            <span>Слайд {activeSlide + 1} из {slides.length}</span>
                          </div>

                          {/* Индикаторные точки */}
                          <div style={{
                            position: 'absolute',
                            bottom: '16px',
                            left: '50%',
                            transform: 'translateX(-50%)',
                            zIndex: 3,
                            display: 'flex',
                            gap: '8px',
                            background: 'rgba(0,0,0,0.5)',
                            padding: '6px 12px',
                            borderRadius: '50px',
                            backdropFilter: 'blur(4px)',
                          }}>
                            {slides.map((_, i) => (
                              <button
                                key={i}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setActiveSlide(i);
                                }}
                                style={{
                                  width: i === activeSlide ? '24px' : '10px',
                                  height: '10px',
                                  borderRadius: '50px',
                                  background: i === activeSlide ? 'var(--color-gold)' : 'rgba(255,255,255,0.4)',
                                  border: 'none',
                                  cursor: 'pointer',
                                  padding: 0,
                                  transition: 'all 0.3s ease',
                                }}
                                title={`Слайд ${i + 1}`}
                              />
                            ))}
                          </div>
                        </>
                      )}

                      {/* Подсказка клика */}
                      <div style={{
                        position: 'absolute',
                        bottom: '12px',
                        right: '12px',
                        zIndex: 3,
                        background: 'rgba(0,0,0,0.7)',
                        color: 'white',
                        padding: '6px 14px',
                        borderRadius: '50px',
                        fontSize: '0.8rem',
                        fontWeight: '600',
                        backdropFilter: 'blur(6px)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        pointerEvents: 'none',
                      }}>
                        <span>🔍 Нажмите для полного экрана</span>
                      </div>
                    </div>
                  ) : (
                    <div style={{
                      height: '350px',
                      background: 'linear-gradient(135deg, var(--color-dark-green), var(--color-green))',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'rgba(255,255,255,0.7)',
                    }}>
                      <MuseumIcon width={64} height={64} color="rgba(255,255,255,0.7)" />
                      <span style={{ marginTop: '0.5rem', fontSize: '0.9rem' }}>Фото объекта</span>
                    </div>
                  )}

                  {/* Описание текущего слайда и миниатюры */}
                  <div style={{
                    background: 'white',
                    borderTop: '1px solid #f0f0f0',
                    padding: '1.25rem 1.5rem',
                  }}>
                    {currentSlide.title && (
                      <div style={{ marginBottom: slides.length > 1 ? '1rem' : '0.5rem' }}>
                        <div style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: '1rem',
                          flexWrap: 'wrap',
                          marginBottom: '4px',
                        }}>
                          <h4 style={{
                            margin: 0,
                            fontSize: '1.05rem',
                            color: 'var(--color-dark-green)',
                            fontWeight: '700',
                          }}>
                            {currentSlide.title}
                          </h4>
                          {slides.length > 1 && (
                            <span style={{
                              fontSize: '0.8rem',
                              fontWeight: '600',
                              color: 'var(--color-gold)',
                              background: 'var(--color-beige)',
                              padding: '2px 10px',
                              borderRadius: '20px',
                            }}>
                              Фото {activeSlide + 1} из {slides.length}
                            </span>
                          )}
                        </div>
                        {currentSlide.desc && (
                          <p style={{
                            margin: 0,
                            fontSize: '0.92rem',
                            color: 'var(--color-text)',
                            lineHeight: '1.55',
                          }}>
                            {currentSlide.desc}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Галерея миниатюр (превью всех слайдов) */}
                    {slides.length > 1 && (
                      <div style={{
                        marginTop: '1rem',
                        paddingTop: '1rem',
                        borderTop: '1px dashed #e8e8e8',
                      }}>
                        <div style={{
                          fontSize: '0.8rem',
                          fontWeight: '700',
                          color: 'var(--color-text-light)',
                          textTransform: 'uppercase',
                          letterSpacing: '0.5px',
                          marginBottom: '0.75rem',
                        }}>
                          Все фотографии ({slides.length}):
                        </div>
                        <div style={{
                          display: 'grid',
                          gridTemplateColumns: `repeat(${slides.length}, 1fr)`,
                          gap: '12px',
                        }}>
                          {slides.map((slide, idx) => (
                            <div
                              key={idx}
                              onClick={() => setActiveSlide(idx)}
                              style={{
                                cursor: 'pointer',
                                borderRadius: '10px',
                                overflow: 'hidden',
                                position: 'relative',
                                height: '80px',
                                border: idx === activeSlide
                                  ? '3px solid var(--color-gold)'
                                  : '2px solid transparent',
                                boxShadow: idx === activeSlide
                                  ? '0 0 12px rgba(201,162,39,0.5)'
                                  : '0 2px 6px rgba(0,0,0,0.08)',
                                transform: idx === activeSlide ? 'scale(1.02)' : 'scale(1)',
                                transition: 'all 0.25s ease',
                              }}
                              title={slide.title}
                            >
                              <img
                                src={slide.url}
                                alt={slide.title}
                                style={{
                                  width: '100%',
                                  height: '100%',
                                  objectFit: 'cover',
                                  display: 'block',
                                }}
                              />
                              <div style={{
                                position: 'absolute',
                                bottom: '4px',
                                right: '4px',
                                background: idx === activeSlide ? 'var(--color-gold)' : 'rgba(0,0,0,0.65)',
                                color: idx === activeSlide ? '#0d2b1d' : 'white',
                                fontSize: '0.7rem',
                                fontWeight: '700',
                                padding: '1px 6px',
                                borderRadius: '4px',
                              }}>
                                {idx + 1}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {monument.imageCredit && (
                      <div style={{
                        marginTop: '1rem',
                        paddingTop: '0.75rem',
                        borderTop: '1px solid #f5f5f5',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        fontSize: '0.8rem',
                        color: 'var(--color-text-light)',
                        flexWrap: 'wrap',
                        gap: '0.5rem',
                      }}>
                        <span>📷 Источник: {monument.imageCredit}</span>
                        <button
                          onClick={() => setLightboxOpen(true)}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: 'var(--color-green)',
                            fontWeight: '600',
                            cursor: 'pointer',
                            fontSize: '0.82rem',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px',
                          }}
                        >
                          Открыть во весь экран ↗
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </FadeIn>

              {/* История */}
              <FadeIn delay={100}>
                <div style={{ background: 'white', borderRadius: '14px', padding: '2.25rem', marginBottom: '1.5rem', boxShadow: '0 2px 15px rgba(0,0,0,0.05)' }}>
                  <h2 style={{ color: 'var(--color-dark-green)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <ScrollIcon width={24} height={24} color="var(--color-green)" />
                    <span>История объекта</span>
                  </h2>
                  {monument.fullDesc.split('\n\n').map((para, i) => (
                    <p key={i} style={{ color: 'var(--color-text)', lineHeight: '1.85', fontSize: '1.02rem', marginBottom: '1.25rem' }}>
                      {para}
                    </p>
                  ))}
                </div>
              </FadeIn>

              {/* Интересные факты */}
              {monument.facts && monument.facts.length > 0 && (
                <FadeIn delay={150}>
                  <div style={{ background: 'white', borderRadius: '14px', padding: '2.25rem', marginBottom: '1.5rem', boxShadow: '0 2px 15px rgba(0,0,0,0.05)' }}>
                    <h2 style={{ color: 'var(--color-dark-green)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <StarIcon width={24} height={24} color="var(--color-gold)" />
                      <span>Интересные исторические факты</span>
                    </h2>
                    <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                      {monument.facts.map((fact, i) => (
                        <li key={i} style={{
                          display: 'flex',
                          gap: '1rem',
                          padding: '1rem 1.25rem',
                          background: 'var(--color-beige)',
                          borderRadius: '10px',
                          fontSize: '0.95rem',
                          lineHeight: '1.6',
                          alignItems: 'flex-start',
                        }}>
                          <span style={{
                            width: '8px',
                            height: '8px',
                            borderRadius: '50%',
                            background: 'var(--color-gold)',
                            marginTop: '8px',
                            flexShrink: 0,
                          }} />
                          <span>{fact}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </FadeIn>
              )}

              {/* Почему важно сохранить */}
              <FadeIn delay={200}>
                <div style={{
                  background: 'linear-gradient(135deg, var(--color-dark-green), #143e2b)',
                  borderRadius: '14px',
                  padding: '2.25rem',
                  color: 'white',
                  marginBottom: '1.5rem',
                  boxShadow: '0 5px 20px rgba(0,0,0,0.1)',
                }}>
                  <h2 style={{ color: 'var(--color-gold-light)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <ShieldIcon width={24} height={24} color="var(--color-gold-light)" />
                    <span>Почему важно сохранить это место?</span>
                  </h2>
                  <p style={{ color: 'rgba(255,255,255,0.9)', lineHeight: '1.8', marginBottom: '1rem', fontSize: '1rem' }}>
                    {monument.significance}. Каждый исторический памятник Берёзовского — это живое свидетельство
                    труда многих поколений уральских горняков, строивших индустриальную славу России.
                  </p>
                  <p style={{ color: 'rgba(255,255,255,0.75)', lineHeight: '1.8', margin: 0, fontSize: '0.95rem' }}>
                    Сохранение исторического наследия — долг перед будущими поколениями.
                    Знание истории родного края формирует уважение к предкам и культуре малой родины.
                  </p>
                </div>
              </FadeIn>

              {/* Источники информации */}
              {monument.sources && monument.sources.length > 0 && (
                <FadeIn delay={250}>
                  <div style={{ background: 'white', borderRadius: '14px', padding: '1.75rem', boxShadow: '0 2px 15px rgba(0,0,0,0.05)' }}>
                    <h3 style={{ color: 'var(--color-dark-green)', marginBottom: '1rem', fontSize: '1.05rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <BookIcon width={18} height={18} color="var(--color-green)" />
                      <span>Источники информации</span>
                    </h3>
                    <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                      {monument.sources.map((src, i) => (
                        <li key={i} style={{ fontSize: '0.88rem', color: 'var(--color-text-light)', display: 'flex', gap: '0.6rem' }}>
                          <span style={{ color: 'var(--color-green)' }}>•</span>
                          <span>{src}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </FadeIn>
              )}
            </div>

            {/* Боковая панель */}
            <div>
              {/* Краткие сведения */}
              <FadeIn>
                <div className="info-box" style={{ marginBottom: '1.5rem', background: 'white', boxShadow: '0 2px 15px rgba(0,0,0,0.05)' }}>
                  <h3 style={{ color: 'var(--color-dark-green)', marginBottom: '1.25rem', fontSize: '1.05rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <ScrollIcon width={18} height={18} color="var(--color-green)" />
                    <span>Сведения об объекте</span>
                  </h3>

                  <div className="info-row">
                    <div className="info-icon"><MapPinIcon width={20} height={20} color="var(--color-green)" /></div>
                    <div>
                      <div className="info-label">Адрес / расположение</div>
                      <div className="info-value">{monument.address}</div>
                    </div>
                  </div>

                  <div className="info-row">
                    <div className="info-icon"><CatIcon width={20} height={20} color="var(--color-gold)" /></div>
                    <div>
                      <div className="info-label">Категория</div>
                      <div className="info-value">{cat?.label}</div>
                    </div>
                  </div>

                  <div className="info-row">
                    <div className="info-icon"><CalendarIcon width={20} height={20} color="var(--color-green)" /></div>
                    <div>
                      <div className="info-label">Год основания / создания</div>
                      <div className="info-value">{monument.yearBuilt}</div>
                    </div>
                  </div>

                  <div className="info-row">
                    <div className="info-icon"><ShieldIcon width={20} height={20} color="var(--color-green)" /></div>
                    <div>
                      <div className="info-label">Статус посещения</div>
                      <div className="info-value">{monument.status}</div>
                    </div>
                  </div>
                </div>
              </FadeIn>

              {/* Кнопки навигации */}
              <FadeIn delay={100}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', marginBottom: '1.5rem' }}>
                  <Link
                    to={`/map?id=${monument.id}`}
                    className="btn btn-green"
                    style={{ justifyContent: 'center' }}
                  >
                    <MapPinIcon width={18} height={18} color="white" />
                    <span>Показать на общей Яндекс Карте</span>
                  </Link>

                  {/* Плашка геолокации и расстояния */}
                  {userLocation ? (
                    <div style={{
                      background: 'rgba(45,106,79,0.08)',
                      border: '1px solid rgba(45,106,79,0.2)',
                      borderRadius: '10px',
                      padding: '0.65rem 0.9rem',
                      fontSize: '0.84rem',
                      color: 'var(--color-dark-green)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '8px',
                    }}>
                      <span>🚶 До объекта от вас: <strong>{formatDistance(calculateDistance(userLocation.lat, userLocation.lng, monument.lat, monument.lng))?.text}</strong></span>
                      <button
                        onClick={requestLocation}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: '#2d6a4f',
                          fontWeight: '700',
                          fontSize: '0.78rem',
                          cursor: 'pointer',
                          textDecoration: 'underline',
                        }}
                      >
                        Обновить
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={requestLocation}
                      disabled={geoLoading}
                      style={{
                        background: '#f8f9fa',
                        border: '1px dashed #ccc',
                        borderRadius: '10px',
                        padding: '0.55rem',
                        fontSize: '0.82rem',
                        color: '#555',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        fontWeight: '600',
                      }}
                    >
                      <MapPinIcon width={16} height={16} color="#fc3f1d" />
                      <span>{geoLoading ? 'Определение...' : 'Определить моё гео для точного пути'}</span>
                    </button>
                  )}

                  {/* Кнопка Яндекс Карты с точкой пользователя */}
                  <a
                    href={userLocation
                      ? `https://yandex.ru/maps/?rtext=${userLocation.lat}%2C${userLocation.lng}~${monument.lat}%2C${monument.lng}&rtt=pd`
                      : `https://yandex.ru/maps/?rtext=~${monument.lat}%2C${monument.lng}&rtt=pd`}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                      padding: '0.65rem 1.4rem',
                      borderRadius: '50px',
                      color: 'white',
                      background: '#fc3f1d',
                      fontWeight: '700',
                      fontSize: '0.9rem',
                      textDecoration: 'none',
                      boxShadow: '0 3px 10px rgba(252,63,29,0.3)',
                    }}
                  >
                    <span>{userLocation ? 'Маршрут от меня в Яндекс Картах' : 'Маршрут в Яндекс Картах'}</span>
                  </a>

                  {/* Кнопка Google Карты */}
                  <a
                    href={userLocation
                      ? `https://www.google.com/maps/dir/${userLocation.lat},${userLocation.lng}/${monument.lat},${monument.lng}`
                      : `https://www.google.com/maps/dir/?api=1&destination=${monument.lat},${monument.lng}`}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                      padding: '0.65rem 1.4rem',
                      borderRadius: '50px',
                      color: '#1a73e8',
                      background: '#e8f0fe',
                      border: '1px solid #d2e3fc',
                      fontWeight: '600',
                      fontSize: '0.9rem',
                      textDecoration: 'none',
                    }}
                  >
                    <span>Маршрут в Google Maps</span>
                  </a>
                </div>
              </FadeIn>

              {/* Мини-карта объекта на Яндекс Картах */}
              <FadeIn delay={150}>
                <div style={{ marginBottom: '1.5rem' }}>
                  <div style={{ fontSize: '0.8rem', color: '#666', marginBottom: '6px' }}>
                    📍 Точное расположение на Яндекс Картах:
                  </div>
                  <YandexMiniMap
                    lat={monument.lat}
                    lng={monument.lng}
                    title={monument.name}
                    height="260px"
                  />
                </div>
              </FadeIn>

              {/* Навигация */}
              <FadeIn delay={200}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                  <Link to="/monuments" className="btn" style={{
                    justifyContent: 'center',
                    background: 'var(--color-beige-dark)',
                    color: 'var(--color-text)',
                    borderRadius: '50px',
                    padding: '0.75rem',
                    fontWeight: '600',
                    fontSize: '0.9rem',
                  }}>
                    ← Вернуться к каталогу
                  </Link>
                </div>
              </FadeIn>
            </div>
          </div>

          {/* Похожие объекты */}
          {related.length > 0 && (
            <div style={{ marginTop: '3.5rem' }}>
              <FadeIn>
                <h2 style={{ marginBottom: '1.5rem', color: 'var(--color-dark-green)' }}>
                  Похожие объекты категории
                </h2>
              </FadeIn>
              <div className="grid-3">
                {related.map((m, i) => (
                  <FadeIn key={m.id} delay={i * 100}>
                    <div className="card">
                      <div style={{ height: '170px', overflow: 'hidden' }}>
                        <img src={m.image} alt={m.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                          onError={e => { e.target.style.display = 'none'; }} />
                      </div>
                      <div className="card-body">
                        <h3 className="card-title" style={{ fontSize: '1.05rem' }}>{m.name}</h3>
                        <Link to={`/monument/${m.id}`} className="btn btn-green btn-sm" style={{ marginTop: '0.75rem' }}>
                          Подробнее →
                        </Link>
                      </div>
                    </div>
                  </FadeIn>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Полноэкранный просмотрщик фотографии (Lightbox со слайдером) */}
      {lightboxOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 99999,
            background: 'rgba(0, 0, 0, 0.94)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1.5rem',
            backdropFilter: 'blur(10px)',
            animation: 'fadeIn 0.25s ease',
          }}
          onClick={() => setLightboxOpen(false)}
        >
          {/* Кнопка закрыть */}
          <button
            onClick={() => setLightboxOpen(false)}
            style={{
              position: 'absolute',
              top: '20px',
              right: '25px',
              background: 'rgba(255, 255, 255, 0.15)',
              border: 'none',
              color: 'white',
              fontSize: '1.8rem',
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'background 0.2s',
              zIndex: 100001,
            }}
            title="Закрыть (Esc)"
          >
            ✕
          </button>

          {/* Предыдущий слайд в полноэкранном режиме */}
          {slides.length > 1 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                prevSlide();
              }}
              style={{
                position: 'absolute',
                left: '25px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(255, 255, 255, 0.15)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                color: 'white',
                fontSize: '2.5rem',
                width: '60px',
                height: '60px',
                borderRadius: '50%',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s',
                zIndex: 100001,
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'var(--color-gold)';
                e.currentTarget.style.color = '#000';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.15)';
                e.currentTarget.style.color = 'white';
              }}
              title="Предыдущее фото (Стрелка влево)"
            >
              ‹
            </button>
          )}

          {/* Следующий слайд в полноэкранном режиме */}
          {slides.length > 1 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                nextSlide();
              }}
              style={{
                position: 'absolute',
                right: '25px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(255, 255, 255, 0.15)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                color: 'white',
                fontSize: '2.5rem',
                width: '60px',
                height: '60px',
                borderRadius: '50%',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s',
                zIndex: 100001,
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'var(--color-gold)';
                e.currentTarget.style.color = '#000';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.15)';
                e.currentTarget.style.color = 'white';
              }}
              title="Следующее фото (Стрелка вправо)"
            >
              ›
            </button>
          )}

          {/* Заголовок слайда */}
          <div style={{
            color: 'white',
            fontSize: '1.15rem',
            fontWeight: '700',
            marginBottom: '0.75rem',
            textAlign: 'center',
            textShadow: '0 2px 10px rgba(0,0,0,0.9)',
            maxWidth: '800px',
          }}>
            {currentSlide.title || monument.name}
            {slides.length > 1 && (
              <span style={{
                marginLeft: '10px',
                fontSize: '0.85rem',
                color: 'var(--color-gold)',
                fontWeight: '600',
              }}>
                ({activeSlide + 1} / {slides.length})
              </span>
            )}
          </div>

          {/* Изображение во весь экран */}
          <img
            key={`lightbox-${activeSlide}`}
            src={currentSlide.url}
            alt={currentSlide.title || monument.name}
            style={{
              maxWidth: '88vw',
              maxHeight: '75vh',
              objectFit: 'contain',
              borderRadius: '8px',
              boxShadow: '0 10px 45px rgba(0,0,0,0.9)',
              transition: 'opacity 0.2s ease',
            }}
            onClick={(e) => e.stopPropagation()}
          />

          {/* Описание слайда в полноэкранном режиме */}
          {currentSlide.desc && (
            <div style={{
              color: 'rgba(255,255,255,0.9)',
              fontSize: '0.92rem',
              maxWidth: '750px',
              textAlign: 'center',
              marginTop: '0.85rem',
              lineHeight: '1.45',
              textShadow: '0 2px 8px rgba(0,0,0,0.8)',
            }}>
              {currentSlide.desc}
            </div>
          )}

          {/* Миниатюры внизу в лайтбоксе */}
          {slides.length > 1 && (
            <div
              style={{
                display: 'flex',
                gap: '10px',
                marginTop: '1rem',
                zIndex: 100001,
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {slides.map((s, idx) => (
                <div
                  key={idx}
                  onClick={() => setActiveSlide(idx)}
                  style={{
                    width: '60px',
                    height: '42px',
                    borderRadius: '6px',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    border: idx === activeSlide ? '2px solid var(--color-gold)' : '1px solid rgba(255,255,255,0.3)',
                    opacity: idx === activeSlide ? 1 : 0.6,
                    transform: idx === activeSlide ? 'scale(1.08)' : 'scale(1)',
                    transition: 'all 0.2s ease',
                  }}
                  title={s.title}
                >
                  <img src={s.url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
              ))}
            </div>
          )}

          <div style={{
            color: 'rgba(255,255,255,0.6)',
            fontSize: '0.8rem',
            marginTop: '0.65rem',
          }}>
            {monument.imageCredit ? `Источник: ${monument.imageCredit}` : ''} · Нажмите в любое место или Esc, чтобы закрыть
          </div>
        </div>
      )}
    </>
  );
}
