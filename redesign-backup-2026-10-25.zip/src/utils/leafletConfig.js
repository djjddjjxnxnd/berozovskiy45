import L from 'leaflet';

// Исправление стандартных путей к иконкам маркеров Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Отключаем префикс Leaflet со встроенным флагом
if (L.Control && L.Control.Attribution) {
  L.Control.Attribution.prototype.options.prefix = false;
}
