import { MapContainer, Marker, Polyline, Popup, TileLayer } from 'react-leaflet';
import L from 'leaflet';
import '../utils/leafletConfig';

const stopPin = (color, number) => L.divIcon({
  className: 'heritage-marker-wrap',
  html: `<span class="heritage-marker heritage-marker-number" style="--marker-color:${color}"><b>${number}</b></span>`,
  iconSize: [34, 42], iconAnchor: [17, 42], popupAnchor: [0, -38],
});

export default function YandexRouteMap({ stops = [], routeColor = '#e2a74b', height = '380px', userLocation = null }) {
  const points = stops.map((stop) => stop.coords);
  const center = points[0] || [56.91185, 60.80410];
  return (
    <div className="open-map" style={{ height }}>
      <MapContainer center={center} zoom={14} scrollWheelZoom className="leaflet-map">
        <TileLayer attribution='&copy; OpenStreetMap' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {points.length > 1 && <Polyline positions={points} pathOptions={{ color: routeColor, weight: 5, opacity: 0.85 }} />}
        {stops.map((stop) => <Marker key={stop.num} position={stop.coords} icon={stopPin(routeColor, stop.num)}><Popup><strong>{stop.num}. {stop.name}</strong><br />{stop.desc}</Popup></Marker>)}
        {userLocation && <Marker position={[userLocation.lat, userLocation.lng]} icon={stopPin('#2677d9', '●')}><Popup>Вы здесь</Popup></Marker>}
      </MapContainer>
    </div>
  );
}
