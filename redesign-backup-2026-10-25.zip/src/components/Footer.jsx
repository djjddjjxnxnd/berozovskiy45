import { Link } from 'react-router-dom';
import { HammersIcon } from './Icons';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-grid">
        <div>
          <div className="footer-brand" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <img
              src="/coat-of-arms.webp"
              alt="Герб Берёзовского"
              style={{ height: '36px', width: 'auto', filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.5))' }}
            />
            <span>Неизвестный Берёзовский</span>
          </div>
          <p style={{ fontSize: '0.9rem', lineHeight: '1.6', marginBottom: '1rem' }}>
            Школьный исследовательский проект по краеведению и истории.
            Берёзовский, Свердловская область, Россия.
          </p>
          <p style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.5)' }}>
            Краеведческий интернет-путеводитель
          </p>
        </div>

        <div className="footer-links">
          <h4>Разделы</h4>
          <ul>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/monuments">Памятники</Link></li>
            <li><Link to="/map">Карта</Link></li>
            <li><Link to="/history">История</Link></li>
            <li><Link to="/routes">Маршруты</Link></li>
          </ul>
        </div>

        <div className="footer-links">
          <h4>Проект</h4>
          <ul>
            <li><Link to="/preserve">Сохраним вместе</Link></li>
            <li><Link to="/preserve#form">Расскажи о месте</Link></li>
            <li><Link to="/preserve#sources">Источники</Link></li>
          </ul>
        </div>

        <div className="footer-links">
          <h4>Информация</h4>
          <ul>
            <li><a href="https://berezovsky.ru" target="_blank" rel="noreferrer">Сайт города Берёзовский</a></li>
            <li><a href="https://museum-zoloto.ru" target="_blank" rel="noreferrer">Музей золота</a></li>
            <li><a href="https://openstreetmap.org" target="_blank" rel="noreferrer">OpenStreetMap</a></li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <p>
          © 2024–2025 «Неизвестный Берёзовский — история рядом с нами» &nbsp;·&nbsp;
          Школьный исследовательский проект по краеведению &nbsp;·&nbsp;
          Все исторические сведения и фотографии основаны на подлинных источниках
        </p>
      </div>
    </footer>
  );
}
