import { useEffect, useState } from 'react';

export default function PhotoCarousel({ images, alt }) {
  const slides = [...new Set(images)].slice(0, 5);
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused || slides.length < 2) return undefined;
    const timer = window.setInterval(() => setActive(current => (current + 1) % slides.length), 4800);
    return () => window.clearInterval(timer);
  }, [paused, slides.length]);

  if (!slides.length) return null;

  const move = (step) => setActive(current => (current + step + slides.length) % slides.length);

  return (
    <div className="photo-carousel" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className="photo-carousel-track" style={{ transform: `translateX(-${active * 100}%)` }}>
        {slides.map((src, index) => (
          <img key={src} src={src} alt={`${alt} — фото ${index + 1}`} className="photo-carousel-image" loading={index ? 'lazy' : 'eager'} />
        ))}
      </div>
      {slides.length > 1 && <>
        <button type="button" className="photo-carousel-arrow prev" aria-label="Предыдущее фото" onClick={() => move(-1)}>‹</button>
        <button type="button" className="photo-carousel-arrow next" aria-label="Следующее фото" onClick={() => move(1)}>›</button>
        <div className="photo-carousel-dots">
          {slides.map((src, index) => <button type="button" key={src} className={index === active ? 'active' : ''} aria-label={`Фото ${index + 1}`} onClick={() => setActive(index)} />)}
        </div>
        <span className="photo-carousel-count">{active + 1} / {slides.length}</span>
      </>}
    </div>
  );
}
