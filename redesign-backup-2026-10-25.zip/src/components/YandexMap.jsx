import { useEffect } from 'react';
import { MapContainer, Marker, Popup, TileLayer, useMap } from 'react-leaflet';
import L from 'leaflet';
import '../utils/leafletConfig';
import { categories } from '../data/monuments';

const colors = {
  monument: '#e2a74b', museum: '#216f73', architecture: '#6f8f57',
  memorial: '#b84b48', leisure: '#2f9b90', hidden: '#9a7132',
};

const markerIcon = (color, label = '') => L.divIcon({
  className: 'heritage-marker-wrap',
  html: `<span class="heritage-marker" style="--marker-color:${color}">${label}</span>`,
  iconSize: [34, 42], iconAnchor: [17, 42], popupAnchor: [0, -38],
});

function MapFocus({ selected }) {
  const map = useMap();
  useEffect(() => {
    if (selected) map.flyTo([selected.lat, selected.lng], 16, { duration: 0.8 });
  }, [map, selected]);
  return null;
}

function MapResize() {
  const map = useMap();
  useEffect(() => {
    const timer = window.setTimeout(() => map.invalidateSize(), 80);
    return () => window.clearTimeout(timer);
  }, [map]);
  return null;
}

export default function YandexMap({
  monuments = [], selectedMonument = null, onSelectMonument = () => {},
  center = [56.9150, 60.8120], zoom = 13, height = '560px', userLocation = null,
}) {
  return (
    <div className="open-map" style={{ height }}>
      <MapContainer center={center} zoom={zoom} scrollWheelZoom className="leaflet-map">
        <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <MapResize />
        <MapFocus selected={selectedMonument} />
        {monuments.map((monument) => {
          const cat = categories.find((item) => item.id === monument.category);
          return (
            <Marker key={monument.id} position={[monument.lat, monument.lng]} icon={markerIcon(colors[monument.category] || '#216f73')} eventHandlers={{ click: () => onSelectMonument(monument) }}>
              <Popup>
                <div className="map-popup">
                  <img src={monument.image} alt={monument.name} />
                  <span className="map-popup-category">{cat?.label}</span>
                  <h4>{monument.name}</h4>
                  <p>{monument.shortDesc.slice(0, 110)}…</p>
                  <a href={`/monument/${monument.id}`}>Открыть объект</a>
                </div>
              </Popup>
            </Marker>
          );
        })}
        {userLocation && <Marker position={[userLocation.lat, userLocation.lng]} icon={markerIcon('#2677d9', '●')}><Popup>Вы находитесь здесь</Popup></Marker>}
      </MapContainer>
    </div>
  );
}
