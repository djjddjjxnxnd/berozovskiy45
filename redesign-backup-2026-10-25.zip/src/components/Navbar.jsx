import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { HammersIcon } from './Icons';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo(0, 0);
  }, [location.pathname]);

  const links = [
    { to: '/', label: 'Главная' },
    { to: '/monuments', label: 'Памятники' },
    { to: '/map', label: 'Карта' },
    { to: '/history', label: 'История' },
    { to: '/routes', label: 'Маршруты' },
    { to: '/preserve', label: 'Сохраним вместе' },
  ];

  return (
    <nav className="navbar" style={{ height: scrolled ? '60px' : '70px', transition: 'height 0.3s' }}>
      <Link to="/" className="navbar-brand">
        <img
          src="/coat-of-arms.webp"
          alt="Герб города Берёзовский"
          style={{
            height: scrolled ? '34px' : '40px',
            width: 'auto',
            filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.35))',
            transition: 'height 0.3s ease',
            flexShrink: 0,
          }}
        />
        <span className="brand-text">
          <span>Неизвестный Берёзовский</span>
          <span>история рядом с нами</span>
        </span>
      </Link>

      <ul className={`navbar-nav${menuOpen ? ' open' : ''}`}>
        {links.map(l => (
          <li key={l.to}>
            <Link
              to={l.to}
              className={location.pathname === l.to ? 'active' : ''}
            >
              {l.label}
            </Link>
          </li>
        ))}
      </ul>

      <button
        className="navbar-toggle"
        onClick={() => setMenuOpen(o => !o)}
        aria-label="Меню"
      >
        <span style={{ transform: menuOpen ? 'rotate(45deg) translate(4px, 4px)' : '' }} />
        <span style={{ opacity: menuOpen ? 0 : 1 }} />
        <span style={{ transform: menuOpen ? 'rotate(-45deg) translate(4px, -4px)' : '' }} />
      </button>
    </nav>
  );
}
