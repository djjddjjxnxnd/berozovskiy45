import { MapContainer, Marker, Popup, TileLayer } from 'react-leaflet';
import L from 'leaflet';
import '../utils/leafletConfig';

const pin = (color) => L.divIcon({
  className: 'heritage-marker-wrap',
  html: `<span class="heritage-marker" style="--marker-color:${color}"></span>`,
  iconSize: [34, 42], iconAnchor: [17, 42], popupAnchor: [0, -38],
});

export default function YandexMiniMap({ lat, lng, title, pinColor = '#e2a74b', height = '270px' }) {
  return (
    <div className="open-map" style={{ height }}>
      <MapContainer center={[lat, lng]} zoom={16} scrollWheelZoom className="leaflet-map">
        <TileLayer attribution='&copy; OpenStreetMap' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Marker position={[lat, lng]} icon={pin(pinColor)}><Popup>{title}</Popup></Marker>
      </MapContainer>
    </div>
  );
}
