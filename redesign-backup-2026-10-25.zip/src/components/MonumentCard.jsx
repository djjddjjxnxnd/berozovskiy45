import { Link } from 'react-router-dom';
import { categories } from '../data/monuments';
import PhotoCarousel from './PhotoCarousel';
import { MapPinIcon, ChurchIcon, MuseumIcon, MonumentIcon, StarIcon, HiddenPlaceIcon, HammersIcon, ParkIcon } from './Icons';

const iconMap = {
  monument: MonumentIcon,
  architecture: ChurchIcon,
  museum: MuseumIcon,
  memorial: StarIcon,
  leisure: ParkIcon,
  hidden: HiddenPlaceIcon,
  all: HammersIcon,
};

export default function MonumentCard({ monument, showMapBtn = true }) {
  const cat = categories.find(c => c.id === monument.category);
  const CatIcon = iconMap[monument.category] || MonumentIcon;
  const gallery = (monument.images || [{ url: monument.image }]).map(({ url }) => url);

  return (
    <div className="card">
      {/* Изображение с правильным кадрированием */}
      <div style={{ position: 'relative', overflow: 'hidden', height: '220px', background: 'var(--color-dark-green)' }}>
        <PhotoCarousel images={gallery} alt={monument.name} />
        <div className="img-placeholder" style={{ display: 'none', height: '220px' }}>
          <MuseumIcon width={48} height={48} color="rgba(255,255,255,0.6)" />
          <span>Фото объекта</span>
        </div>
        <div style={{
          position: 'absolute',
          top: '12px',
          left: '12px',
          background: 'rgba(26,71,49,0.92)',
          color: '#f4d03f',
          fontSize: '0.72rem',
          fontWeight: '700',
          padding: '4px 10px',
          borderRadius: '50px',
          backdropFilter: 'blur(4px)',
          display: 'inline-flex',
          alignItems: 'center',
          gap: '5px',
        }}>
          <CatIcon width={14} height={14} color="#f4d03f" />
          <span>{cat?.label || monument.category}</span>
        </div>

        {monument.images && monument.images.length > 1 && (
          <div style={{
            position: 'absolute',
            top: '12px',
            right: '12px',
            background: 'rgba(0,0,0,0.75)',
            color: 'white',
            fontSize: '0.72rem',
            fontWeight: '700',
            padding: '4px 9px',
            borderRadius: '50px',
            backdropFilter: 'blur(4px)',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '4px',
            border: '1px solid rgba(255,255,255,0.2)',
          }}>
            <span>📸</span>
            <span>{monument.images.length} фото</span>
          </div>
        )}
      </div>

      <div className="card-body">
        <h3 className="card-title">{monument.name}</h3>
        <p style={{
          fontSize: '0.8rem',
          color: 'var(--color-gold)',
          marginBottom: '0.5rem',
          fontWeight: '600',
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
        }}>
          <MapPinIcon width={14} height={14} color="var(--color-gold)" />
          <span>{monument.address}</span>
        </p>
        <p className="card-desc">{monument.shortDesc}</p>

        {monument.status && (
          <div style={{
            fontSize: '0.78rem',
            color: monument.status.includes('Открыт') || monument.status.includes('Действует') || monument.status.includes('Действующий')
              ? 'var(--color-green)' : 'var(--color-text-light)',
            marginBottom: '1rem',
            fontWeight: '600',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
          }}>
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: monument.status.includes('Открыт') || monument.status.includes('Действует') || monument.status.includes('Действующий')
                ? '#2d6a4f' : '#c9a227',
              display: 'inline-block'
            }} />
            <span>{monument.status}</span>
          </div>
        )}

        <div className="card-footer">
          <Link to={`/monument/${monument.id}`} className="btn btn-green btn-sm">
            Узнать историю
          </Link>
          {showMapBtn && (
            <Link to={`/map?id=${monument.id}`} className="btn btn-sm" style={{
              border: '2px solid var(--color-green)',
              color: 'var(--color-green)',
              background: 'transparent',
              borderRadius: '50px',
              padding: '0.5rem 1.1rem',
              fontSize: '0.85rem',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.4rem',
            }}>
              <MapPinIcon width={14} height={14} color="var(--color-green)" />
              <span>На карте</span>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
